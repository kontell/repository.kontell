# -*- coding: utf-8 -*-
"""Artist/album/song writer (fork ``objects/music.py`` port). Adaptations
per plan §3: imports/shims, ``direct_path`` branches stripped (songs stream
from the server), ``self.server`` is the kofin Api, and the ``musicTranscode``
setting picks between the fork's direct stream URLs and kofin plugin paths."""

import datetime

from kofin.core import settings
from kofin.core.log import Logger
from kofin.sync import downloader as server
from kofin.sync import kofindb as jellyfin_db
from kofin.sync import queries_map as QUEM
from kofin.sync import fields as api
from kofin.sync.fields import check_unchanged, find_library
from kofin.sync.hooks import WriterHooks
from kofin.sync.shims import stop, jellyfin_item, values, Local

from kofin.sync.obj import Objects
from kofin.sync.kodidb import Music as KodiDb
from kofin.sync.kodidb.music import BLANKARTIST_ID, BLANKARTIST_NAME
from kofin.sync.kodidb import queries_music as QU

##################################################################################################

LOG = Logger(__name__)
# Nested relink_content passes allowed: a relinked song can create another
# late artist inline, which relinks in turn. Real chains are one or two deep;
# past this the artist is written and its content left to a repair.
RELINK_MAX_DEPTH = 3

##################################################################################################


class Music(KodiDb):

    def __init__(self, server, jellyfindb, musicdb, library=None, hooks=None):

        self.server = server
        self.jellyfin = jellyfindb
        self.music = musicdb
        # Native mode is gone; the flag stays because the checksum format
        # bakes it in ("<etag>|plugin") and check_unchanged reads it.
        self.direct_path = False
        # Read once per writer rather than per song: settings.get_bool builds
        # a fresh xbmcaddon.Addon each call and a music library is tens of
        # thousands of songs. A flip only takes effect on the repair the
        # setting's help text asks for, which rebuilds the writers anyway.
        self.music_transcode = settings.get_bool("musicTranscode")

        self.jellyfin_db = jellyfin_db.JellyfinDatabase(jellyfindb.cursor)
        self.objects = Objects()
        self.item_ids = []
        self.library = library
        # What the pipeline adds to a write that the writer does not own
        # (kofin.sync.hooks): the downloads tag and repoint, for one. Empty
        # means the fork's rows and nothing more.
        self.hooks = hooks or WriterHooks()
        # Memo for find_library, per writer instance (see fields.find_library).
        self.library_cache = {}
        # Ids this writer declined to write, so the caller can tell a
        # refusal from a write. A writer refuses by returning early, and
        # the return value cannot carry the news: it already means
        # something else (tvshow returns None on unchanged *so that* full
        # sync still walks its episodes). See UpdateWorker's notify gate.
        self.refused = set()
        # Memo for the music view list behind source naming (music_views).
        self._music_views = None
        # How many relink_content passes are on the stack: a relinked song
        # can create yet another late artist inline, and that one relinks
        # too. Bounded, see RELINK_MAX_DEPTH.
        self._relink_depth = 0

        KodiDb.__init__(self, musicdb.cursor)

    @stop
    @jellyfin_item
    def artist(self, item, e_item, library=None, skip=None):
        """If item does not exist, entry will be added.
        If item exists, entry will be updated.

        ``skip`` names the album or song whose own write is creating this
        artist inline; relink_content leaves that item to the write in
        progress.
        """
        server_address = self.server.server
        API = api.API(item, server_address)
        obj = self.objects.map(item, "Artist")
        update = True

        try:
            obj["ArtistId"] = e_item[0]
            obj["LibraryId"] = e_item[6]
            obj["LibraryName"] = self.jellyfin_db.get_view_name(obj["LibraryId"])
        except TypeError:
            update = False

            library = (
                library
                or self.library
                or find_library(self.server, item, self.library_cache)
            )
            if not library:
                # This item doesn't belong to a whitelisted library
                self.refused.add(obj["Id"])
                return

            obj["ArtistId"] = None
            obj["LibraryId"] = library["Id"]
            obj["LibraryName"] = library["Name"]
            LOG.debug("ArtistId %s not found", obj["Id"])
        else:
            if self.validate_artist(*values(obj, QU.get_artist_by_id_obj)) is None:

                update = False
                LOG.info(
                    "ArtistId %s missing from kodi. repairing the entry.",
                    obj["ArtistId"],
                )

        if check_unchanged(self, obj, item, e_item, update):
            return

        obj["LastScraped"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        obj["ArtistType"] = "MusicArtist"
        obj["Genre"] = " / ".join(obj["Genres"] or [])
        obj["Bio"] = API.get_overview(obj["Bio"])
        obj["Artwork"] = API.get_all_artwork(
            self.objects.map(item, "ArtworkMusic"), True
        )
        obj["Thumb"] = obj["Artwork"]["Primary"]
        obj["Backdrops"] = obj["Artwork"]["Backdrop"] or ""

        if obj["Thumb"]:
            obj["Thumb"] = "<thumb>%s</thumb>" % obj["Thumb"]

        if obj["Backdrops"]:
            obj["Backdrops"] = "<fanart>%s</fanart>" % obj["Backdrops"][0]

        if update:
            self.artist_update(obj)
        else:
            self.artist_add(obj)

        self.update(
            obj["Genre"],
            obj["Bio"],
            obj["Thumb"],
            obj["Backdrops"],
            obj["LastScraped"],
            obj["ArtistId"],
        )
        self.artwork.add(obj["Artwork"], obj["ArtistId"], "artist")
        self.item_ids.append(obj["Id"])

        # A new row on the realtime path may post-date the content that
        # credits it (issue #188). A full sync -- the writer built with its
        # library -- writes artists before albums before songs, so there is
        # nothing to relink and it never pays for the listing.
        if not update and self.library is None:
            self.relink_content(obj, skip)

    def artist_add(self, obj):
        """Add object to kodi.

        safety checks: It looks like Jellyfin supports the same artist multiple times.
        Kodi doesn't allow that. In case that happens we just merge the artist entries.
        """
        obj["ArtistId"] = self.get(*values(obj, QU.get_artist_obj))
        self.jellyfin_db.add_reference(*values(obj, QUEM.add_reference_artist_obj))
        LOG.debug("ADD artist [%s] %s: %s", obj["ArtistId"], obj["Name"], obj["Id"])

    def artist_update(self, obj):
        """Update object to kodi."""
        self.jellyfin_db.update_reference(*values(obj, QUEM.update_reference_obj))
        LOG.debug("UPDATE artist [%s] %s: %s", obj["ArtistId"], obj["Name"], obj["Id"])

    def relink_content(self, obj, skip=None):
        """Re-credit what kofin already holds of an artist that arrived after it.

        Jellyfin fills a track's ArtistItems by looking its tag names up
        against the artist entities that exist at the moment of the request
        (DtoService: GetArtists(names) is a lookup, never a create) and
        creates the entities in a post-scan pass, after the tracks are
        saved. A track written between the two carries no entity for its
        own artist, so song_artist_link falls back to the album artist; the
        artist-added event that follows names only the artist, the tracks'
        Etags never move, and nothing rewrites them -- three guest artists
        on a Nick Cave album sat unreachable from every listing for hours,
        healed only by an unrelated server rewrite (issue #188). The
        knowledge lives here, on the artist-added path: one listing of the
        artist's content, and every album or song kofin already maps that
        lacks this artist's link is rewritten in place with the ArtistItems
        the server serves now, through the Etag match. An album is only
        rewritten when the artist is one of *its* album artists; a
        contributor's album is reached through the song credit, as Kodi
        reaches it.
        """
        if self._relink_depth >= RELINK_MAX_DEPTH:
            LOG.warning(
                "artist [%s] %s: relink skipped at depth %s; a repair heals it",
                obj["ArtistId"],
                obj["Name"],
                self._relink_depth,
            )
            return

        try:
            listing = self.server.items(
                {
                    "ArtistIds": obj["Id"],
                    "Recursive": True,
                    "IncludeItemTypes": "MusicAlbum,Audio",
                    "Fields": server.music_page_info(),
                    "EnableTotalRecordCount": False,
                }
            )
        except Exception as error:
            LOG.warning(
                "artist [%s] %s: could not list its content to relink it: %s",
                obj["ArtistId"],
                obj["Name"],
                error,
            )
            return

        songs = albums = 0
        self._relink_depth += 1

        try:
            for item in listing.get("Items") or []:
                if item.get("Id") == skip:
                    continue

                e_item = self.jellyfin_db.get_item_by_id(item["Id"])
                if e_item is None:
                    # Not written yet: its own write will link it.
                    continue

                if item.get("Type") == "Audio":
                    if self.song_credits_artist(e_item[0], obj["ArtistId"]):
                        continue

                    self.song(item, force=True)
                    songs += 1
                elif item.get("Type") == "MusicAlbum":
                    album_artists = [
                        a.get("Id") for a in item.get("AlbumArtists") or []
                    ]
                    if obj["Id"] not in album_artists:
                        continue

                    if self.album_has_album_artist(e_item[0], obj["ArtistId"]):
                        continue

                    self.album(item, force=True)
                    albums += 1
        finally:
            self._relink_depth -= 1

        if songs or albums:
            LOG.info(
                "artist [%s] %s arrived after its content: relinked %s songs, %s albums",
                obj["ArtistId"],
                obj["Name"],
                songs,
                albums,
            )
        else:
            LOG.debug("artist [%s] %s: nothing to relink", obj["ArtistId"], obj["Name"])

    @stop
    @jellyfin_item
    def album(self, item, e_item, force=False):
        """Update object to kodi."""
        server_address = self.server.server
        API = api.API(item, server_address)
        obj = self.objects.map(item, "Album")
        update = True

        try:
            obj["AlbumId"] = e_item[0]
            obj["LibraryId"] = e_item[6]
            obj["LibraryName"] = self.jellyfin_db.get_view_name(obj["LibraryId"])
        except TypeError:
            update = False

            library = self.library or find_library(
                self.server, item, self.library_cache
            )
            if not library:
                # This item doesn't belong to a whitelisted library
                self.refused.add(obj["Id"])
                return

            obj["AlbumId"] = None
            obj["LibraryId"] = library["Id"]
            obj["LibraryName"] = library["Name"]
            LOG.debug("AlbumId %s not found", obj["Id"])
        else:
            if self.validate_album(*values(obj, QU.get_album_by_id_obj)) is None:

                update = False
                LOG.info(
                    "AlbumId %s missing from kodi. repairing the entry.", obj["AlbumId"]
                )

        if check_unchanged(self, obj, item, e_item, update, force=force):
            return

        obj["Rating"] = 0
        obj["LastScraped"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        obj["Runtime"] = (obj["Runtime"] or 0) / 10000000.0
        obj["Genres"] = obj["Genres"] or []
        obj["Genre"] = " / ".join(obj["Genres"])
        obj["Bio"] = API.get_overview(obj["Bio"])
        obj["Artists"] = " / ".join(obj["Artists"] or [])
        obj["Artwork"] = API.get_all_artwork(
            self.objects.map(item, "ArtworkMusic"), True
        )
        obj["Thumb"] = obj["Artwork"]["Primary"]
        obj["DateAdded"] = item.get("DateCreated")

        if obj["DateAdded"]:
            obj["DateAdded"] = Local(obj["DateAdded"]).split(".")[0].replace("T", " ")

        if obj["Thumb"]:
            obj["Thumb"] = "<thumb>%s</thumb>" % obj["Thumb"]

        if update:
            self.album_update(obj)
        else:
            self.album_add(obj)

        self.artist_link(obj)
        self.artist_discography(obj)
        self.hooks.after_write("album", self, obj)
        self.update_album(*values(obj, QU.update_album_obj))
        self.update_album_duration(*values(obj, QU.update_album_duration_obj))
        self.add_genres(*values(obj, QU.add_genres_obj))
        self.artwork.add(obj["Artwork"], obj["AlbumId"], "album")
        self.item_ids.append(obj["Id"])

    def music_views(self):
        """The synced music libraries, read once per writer.

        Only the disambiguation of a shared library name needs them, but that
        answer has to be the same one views.py reaches or the node's rule
        matches nothing — so both sides read the same table through the same
        helper.
        """
        if self._music_views is None:
            self._music_views = self.jellyfin_db.get_views_by_media("music")

        return self._music_views

    def album_add(self, obj):
        """Add object to kodi."""
        obj["AlbumId"] = self.get_album(*values(obj, QU.get_album_obj82))
        self.jellyfin_db.add_reference(*values(obj, QUEM.add_reference_album_obj))
        LOG.debug("ADD album [%s] %s: %s", obj["AlbumId"], obj["Title"], obj["Id"])

    def album_update(self, obj):
        """Update object to kodi."""
        self.jellyfin_db.update_reference(*values(obj, QUEM.update_reference_obj))
        LOG.debug("UPDATE album [%s] %s: %s", obj["AlbumId"], obj["Title"], obj["Id"])

    def artist_discography(self, obj):
        """Update the artist's discography."""
        for artist in obj["ArtistItems"] or []:

            temp_obj = dict(obj)
            temp_obj["Id"] = artist["Id"]
            temp_obj["AlbumId"] = obj["Id"]
            temp_obj["ArtistId"] = self._kodi_artist_id(
                artist["Id"],
                skip=obj["Id"],
                library=self._credit_library(obj),
            )
            if temp_obj["ArtistId"] is None:
                continue

            self.add_discography(*values(temp_obj, QU.update_discography_obj))
            self.jellyfin_db.update_parent_id(
                *values(temp_obj, QUEM.update_parent_album_obj)
            )

    def artist_link(self, obj):
        """Assign main artists to album.
        Artist does not exist in jellyfin database, create the reference.

        Deviation from the fork: replace the album's album_artist rows on
        every rewrite, matching prune_song_credits. The fork only ever
        added, so a credit AlbumArtists no longer carries (a MusicBrainz
        conductor left on the album after the server went back to the
        file tag) outlived every Etag change.
        """
        credited = set()
        for artist in obj["AlbumArtists"] or []:

            temp_obj = dict(obj)
            temp_obj["Name"] = artist["Name"]
            temp_obj["Id"] = artist["Id"]
            temp_obj["ArtistId"] = self._kodi_artist_id(
                artist["Id"],
                skip=obj["Id"],
                library=self._credit_library(obj),
            )
            if temp_obj["ArtistId"] is None:
                continue

            self.update_artist_name(*values(temp_obj, QU.update_artist_name_obj))
            self.link(*values(temp_obj, QU.update_link_obj))
            self.item_ids.append(temp_obj["Id"])
            credited.add(temp_obj["ArtistId"])

        self.prune_album_artists(obj["AlbumId"], credited)

    @stop
    @jellyfin_item
    def song(self, item, e_item, force=False):
        """Update object to kodi."""
        server_address = self.server.server
        API = api.API(item, server_address)
        obj = self.objects.map(item, "Song")
        update = True

        try:
            obj["SongId"] = e_item[0]
            obj["PathId"] = e_item[2]
            obj["AlbumId"] = e_item[3]
            obj["LibraryId"] = e_item[6]
            obj["LibraryName"] = self.jellyfin_db.get_view_name(obj["LibraryId"])
        except TypeError:
            update = False

            library = self.library or find_library(
                self.server, item, self.library_cache
            )
            if not library:
                # This item doesn't belong to a whitelisted library
                self.refused.add(obj["Id"])
                return

            obj["SongId"] = self.create_entry_song()
            obj["LibraryId"] = library["Id"]
            obj["LibraryName"] = library["Name"]
            LOG.debug("SongId %s not found", obj["Id"])
        else:
            if self.validate_song(*values(obj, QU.get_song_by_id_obj)) is None:

                update = False
                LOG.info(
                    "SongId %s missing from kodi. repairing the entry.", obj["SongId"]
                )

        if check_unchanged(self, obj, item, e_item, update, force=force):
            return

        self.get_song_path_filename(obj, API)

        obj["Rating"] = 0
        obj["Genres"] = obj["Genres"] or []
        obj["PlayCount"] = API.get_playcount(obj["Played"], obj["PlayCount"])
        obj["Runtime"] = (obj["Runtime"] or 0) / 10000000.0
        obj["Genre"] = " / ".join(obj["Genres"])
        obj["Artists"] = " / ".join(obj["Artists"] or [])
        obj["AlbumArtists"] = obj["AlbumArtists"] or []
        obj["Index"] = obj["Index"] or 0
        obj["Disc"] = obj["Disc"] or 1
        obj["EmbedCover"] = False
        obj["Comment"] = API.get_overview(obj["Comment"])
        obj["Artwork"] = API.get_all_artwork(
            self.objects.map(item, "ArtworkMusic"), True
        )

        if obj["DateAdded"]:
            obj["DateAdded"] = Local(obj["DateAdded"]).split(".")[0].replace("T", " ")

        if obj["DatePlayed"]:
            obj["DatePlayed"] = Local(obj["DatePlayed"]).split(".")[0].replace("T", " ")

        obj["Index"] = obj["Disc"] * 2**16 + obj["Index"]

        if update:
            self.song_update(obj)
        else:
            self.song_add(obj)

        self.add_role(*values(obj, QU.update_role_obj))  # defaultt role
        self.song_artist_link(obj)
        self.song_artist_discography(obj)

        obj["strAlbumArtists"] = " / ".join(obj["AlbumArtists"])
        self.get_album_artist(*values(obj, QU.get_album_artist_obj))

        self.add_genres(*values(obj, QU.update_genre_song_obj))
        self.artwork.add(obj["Artwork"], obj["SongId"], "song")
        self.item_ids.append(obj["Id"])

        if obj["SongAlbumId"] is None:
            self.artwork.add(obj["Artwork"], obj["AlbumId"], "album")

        self.hooks.after_write("song", self, obj)

        return not update

    def song_add(self, obj):
        """Add object to kodi.

        Verify if there's an album associated.
        If no album found, create a single's album
        """
        obj["PathId"] = self.add_path(obj["Path"])

        try:
            obj["AlbumId"] = self.jellyfin_db.get_item_by_id(
                *values(obj, QUEM.get_item_song_obj)
            )[0]
        except TypeError:

            try:
                if obj["SongAlbumId"] is None:
                    raise TypeError("No album id found associated?")

                self.album(self.server.item(obj["SongAlbumId"]))
                obj["AlbumId"] = self.jellyfin_db.get_item_by_id(
                    *values(obj, QUEM.get_item_song_obj)
                )[0]
            except TypeError:
                self.single(obj)

        self.add_song(*values(obj, QU.add_song_obj))
        self.jellyfin_db.add_reference(*values(obj, QUEM.add_reference_song_obj))
        LOG.debug(
            "ADD song [%s/%s/%s] %s: %s",
            obj["PathId"],
            obj["AlbumId"],
            obj["SongId"],
            obj["Id"],
            obj["Title"],
        )

    def song_update(self, obj):
        """Update object to kodi."""
        # Deviation from the fork: the fork rewrote the mapped path row in
        # place and never wrote song.idPath again, so a song whose row had
        # gone kept pointing at nothing — an UPDATE on a missing row is a
        # silent no-op — and no repair could bring it back. The row can go:
        # a downloaded song's server row is referenced by nothing while the
        # download lives, and Kodi's own clean (and kofin's startup prune,
        # before it read the mapping) removes unreferenced rows. In place
        # when the row is there, get-or-create by string when it is not, and
        # the id rides along in update_song either way.
        if self.path_exists(obj["PathId"]):
            self.update_path(*values(obj, QU.update_path_obj))
        else:
            obj["PathId"] = self.add_path(obj["Path"])
            self.jellyfin_db.update_pathid(*values(obj, QUEM.update_pathid_obj))
            LOG.info(
                "song %s had no path row; re-created it as %s",
                obj["SongId"],
                obj["PathId"],
            )

        self.update_song(*values(obj, QU.update_song_obj))
        self.jellyfin_db.update_reference(*values(obj, QUEM.update_reference_obj))
        LOG.debug(
            "UPDATE song [%s/%s/%s] %s: %s",
            obj["PathId"],
            obj["AlbumId"],
            obj["SongId"],
            obj["Id"],
            obj["Title"],
        )

    def get_song_path_filename(self, obj, api):
        """Get the path and filename and build it into protocol://path

        Kodi rebuilds a song's playable path as
        ``URIUtils::AddFileToFolder(path.strPath, song.strFileName)`` — unlike
        the video database there is no "a full URL in strFileName wins" arm
        (``CVideoDatabase::ConstructPath``), so the plugin form has to survive
        that join. Appending to the folder's own filename part gives back
        ``plugin://…/<library>/<id>/stream.<ext>?mode=play&id=<id>``, which the
        router reads by query alone.

        The ``stream.<ext>`` component is load-bearing, not decoration: Kodi
        addresses a library song as ``musicdb://songs/<idSong><ext>`` where
        ``<ext>`` comes from this filename, and
        ``CMusicDatabaseFile::TranslateUrl`` rejects the id outright when that
        extension is missing or disagrees with the row (verified live — an
        extensionless filename fails at ``Init: Error opening file
        musicdb://songs/<id>``, before any plugin resolution). Direct mode
        below has always carried one for the same reason.

        The row stays one path per song, as in direct mode, so
        ``song_update``'s in-place ``update_path`` keeps touching only its own
        song.
        """
        obj["Path"] = api.get_file_path(obj["Path"])
        obj["Filename"] = (
            obj["Path"].rsplit("\\", 1)[1]
            if "\\" in obj["Path"]
            else obj["Path"].rsplit("/", 1)[1]
        )

        if self.music_transcode:
            obj["Path"] = "plugin://plugin.video.kofin/%s/%s/" % (
                obj["LibraryId"],
                obj["Id"],
            )
            obj["Filename"] = "stream.%s?mode=play&id=%s&dbid=%s" % (
                obj["Container"],
                obj["Id"],
                obj["SongId"],
            )
            return

        server_address = self.server.server
        obj["Path"] = "%s/Audio/%s/" % (server_address, obj["Id"])
        obj["Filename"] = "stream.%s?static=true" % obj["Container"]

    def _credit_library(self, obj):
        if not obj.get("LibraryId"):
            return None

        return {"Id": obj["LibraryId"], "Name": obj.get("LibraryName")}

    def _kodi_artist_id(self, jellyfin_id, skip=None, library=None):
        """Kodi id for a Jellyfin artist credit, recreating the row if needed.

        kofin.db can name a kodi_id whose artist row is gone: a MusicArtist
        written before it had albums is invisible to Kodi's CleanupArtists
        keep-set (song_artist ∪ album_artist), and any later DELETE FROM
        artist fires tgrDeleteArtist. The mapping stays, Etag match skips
        artist(), and the next song rewrite would credit the ghost id.
        Recreate through artist() — it already repairs a missing row when
        it runs — and refuse to return a kodi_id that still has no row.
        """
        try:
            kodi_id = self.jellyfin_db.get_item_by_id(jellyfin_id)[0]
        except TypeError:
            kodi_id = None
        else:
            if self.validate_artist(kodi_id) is not None:
                return kodi_id
            LOG.info("ArtistId %s missing from kodi. repairing the entry.", kodi_id)

        try:
            kwargs = {"skip": skip}
            if library is not None:
                kwargs["library"] = library
            self.artist(self.server.item(jellyfin_id), **kwargs)
            kodi_id = self.jellyfin_db.get_item_by_id(jellyfin_id)[0]
        except Exception as error:
            LOG.exception(error)
            return None

        if self.validate_artist(kodi_id) is None:
            return None

        return kodi_id

    def song_artist_discography(self, obj):
        """Update the artist's discography."""
        artists = []
        # Key the row on the album's own title rather than the song's Album
        # tag: Jellyfin reports the two separately and they disagree often
        # enough to matter, and a row under the odd title matches no album
        # in Kodi's fold, so it renders as a stray "0 - <album>". Same title
        # as the album leg means add_discography_if_absent can see the row
        # the album leg already wrote.
        album_title = obj["Album"]

        if album_title:
            album_title = self.get_album_title(obj["AlbumId"]) or album_title

        credited = set()
        for artist in obj["AlbumArtists"] or []:

            temp_obj = dict(obj)
            temp_obj["Name"] = artist["Name"]
            temp_obj["Id"] = artist["Id"]

            artists.append(temp_obj["Name"])
            temp_obj["ArtistId"] = self._kodi_artist_id(
                artist["Id"],
                skip=obj["Id"],
                library=self._credit_library(obj),
            )
            if temp_obj["ArtistId"] is None:
                continue

            self.link(*values(temp_obj, QU.update_link_obj))
            self.item_ids.append(temp_obj["Id"])
            credited.add(temp_obj["ArtistId"])

            if album_title:

                temp_obj["Title"] = album_title
                temp_obj["Year"] = 0
                # Deliberately the if-absent write, not add_discography: this
                # runs once per track and carries no album year, so replacing
                # would stamp a 0 over the year the album writer wrote. The
                # row it does add covers the single, whose album never passes
                # through the album writer at all.
                self.add_discography_if_absent(
                    *values(temp_obj, QU.update_discography_obj)
                )

        # A single's album never passes through artist_link, so this leg
        # owns its album_artist rows and has to replace them the same way.
        if obj["SongAlbumId"] is None:
            self.prune_album_artists(obj["AlbumId"], credited)

        obj["AlbumArtists"] = artists

    def song_artist_link(self, obj):
        """Assign main artists to song.
        Artist does not exist in jellyfin database, create the reference.

        Deviation from the fork: fall back to the album artists when the song
        carries no ArtistItems of its own. Jellyfin serves an empty
        ArtistItems for a song whose artist tag it could not resolve to an
        artist entity, and the fork then wrote no song_artist row at all.
        Kodi reaches an album's songs through song_artist whenever the path
        runs under an artist, so those songs vanished from the artist browse
        while the album itself still listed them -- an album that opens empty.
        Seen live on files whose TPE1 frames had their smart quotes truncated
        to control characters while TPE2 stayed clean, so AlbumArtists
        resolved and ArtistItems did not. Kodi's own scanner credits an
        untagged song to the album artist the same way.

        Second deviation, same rationale taken to its end: at least one row
        is guaranteed. A song both lists come back empty for (a file with no
        artist tags at all) wrote no row and vanished from every song
        listing — Kodi's GetSongsFullByWhere inner-joins songartistview — so
        the last resort is Kodi's own [Missing Tag] blank artist, exactly
        what its scanner files an untagged song under. The blank credit is
        dropped again the moment a rewrite lands a real one.

        Fourth deviation: a mapped kodi_id whose artist row is gone is not
        a credit. The fork trusted the mapping, wrote song_artist at the
        ghost id, and prune_song_credits then dropped every live credit
        that still joined. Kodi's listings inner-join songartistview, so
        the album opened empty; a metadata replace that only moved the
        track's Etag made it stick. Recreate the row (artist() already
        repairs when it runs) and do not add a ghost to ``credited``.
        """
        # Still the {Name, Id} dicts here: song_artist_discography flattens
        # AlbumArtists to names, but it runs after this.
        credited = set()

        for index, artist in enumerate(obj["ArtistItems"] or obj["AlbumArtists"] or []):

            temp_obj = dict(obj)
            temp_obj["Name"] = artist["Name"]
            temp_obj["Id"] = artist["Id"]
            temp_obj["Index"] = index
            temp_obj["ArtistId"] = self._kodi_artist_id(
                artist["Id"],
                skip=obj["Id"],
                library=self._credit_library(obj),
            )
            if temp_obj["ArtistId"] is None:
                continue

            self.link_song_artist(*values(temp_obj, QU.update_song_artist_obj))
            self.item_ids.append(temp_obj["Id"])
            credited.add(temp_obj["ArtistId"])

        if not credited:
            self.link_song_artist(BLANKARTIST_ID, obj["SongId"], 1, 0, BLANKARTIST_NAME)
            credited.add(BLANKARTIST_ID)

        # Third deviation (issue #188): the credits are replaced, as Kodi's
        # own scanner replaces them on an update. The fork only ever added,
        # so the album-artist fallback a track was written with before its
        # own artist existed sat beside the real credit forever once a
        # rewrite finally carried it. The blank placeholder retires the
        # same way.
        self.prune_song_credits(obj["SongId"], credited)

    def single(self, obj):

        obj["AlbumId"] = self.create_entry_album()
        self.add_single(*values(obj, QU.add_single_obj))

    @stop
    @jellyfin_item
    def userdata(self, item, e_item):
        """This updates: Favorite, LastPlayedDate, Playcount, PlaybackPositionTicks
        Poster with progress bar
        """

        obj = self.objects.map(item, "SongUserData")

        try:
            obj["KodiId"] = e_item[0]
            obj["Media"] = e_item[4]
        except TypeError:
            return

        obj["Rating"] = 0

        if obj["Media"] == "song":

            if obj["DatePlayed"]:
                obj["DatePlayed"] = (
                    Local(obj["DatePlayed"]).split(".")[0].replace("T", " ")
                )

            self.rate_song(*values(obj, QU.update_song_rating_obj))

        # The reference checksum tracks metadata state (Etag); userdata
        # changes must not overwrite it.
        LOG.debug(
            "USERDATA %s [%s] %s: %s",
            obj["Media"],
            obj["KodiId"],
            obj["Id"],
            obj["Title"],
        )

    @stop
    @jellyfin_item
    def remove(self, item_id, e_item):
        """This updates: Favorite, LastPlayedDate, Playcount, PlaybackPositionTicks
        Poster with progress bar

        A single (no MusicAlbum on the server) is the song plus the album
        shell ``song_add`` created for it; that shell has no kofin.db row.
        """
        obj = {"Id": item_id}

        try:
            obj["KodiId"] = e_item[0]
            obj["Media"] = e_item[4]
        except TypeError:
            return

        if obj["Media"] == "song":
            obj["ParentId"] = e_item[3]

            self.remove_song(obj["KodiId"], obj["Id"])
            self.jellyfin_db.remove_wild_item(obj["Id"])

            # Deviation from the fork: a single's album is created by
            # song_add and has no kofin.db row. The fork looked it up as
            # jellyfin_id LIKE '<song-id>%' *after* remove_wild_item had
            # already deleted that prefix, so the album was never found
            # and the empty row stayed -- Kodi renders strReleaseType=
            # single with an empty title as "Singles". parent_id on the
            # song mapping is the kodi album id; an empty unmapped album
            # is that shell and goes with the song. A mapped MusicAlbum
            # is left for its own remove.
            if obj["ParentId"] and not self.album_has_songs(obj["ParentId"]):
                if (
                    self.jellyfin_db.get_item_by_kodi_id(obj["ParentId"], "album")
                    is None
                ):
                    self.remove_album(obj["ParentId"], obj["Id"])

        elif obj["Media"] == "album":
            obj["ParentId"] = obj["KodiId"]

            for song in self.jellyfin_db.get_item_by_parent_id(
                *values(obj, QUEM.get_item_by_parent_song_obj)
            ):
                self.remove_song(song[1], obj["Id"])
            self.jellyfin_db.remove_items_by_parent_id(
                *values(obj, QUEM.delete_item_by_parent_song_obj)
            )

            self.remove_album(obj["KodiId"], obj["Id"])

        elif obj["Media"] == "artist":
            obj["ParentId"] = obj["KodiId"]

            # Kodi's own tgrDeleteArtist trigger strips every song_artist
            # row naming the artist when its row goes — including songs on
            # albums this removal never touches (a track on a compilation).
            # Their Etags never move, so no later sync rewrites the link and
            # the songs drop out of every listing for good. Snapshot the
            # credits now; re-credit the survivors after the delete.
            credited = self.get_songs_by_artist(obj["KodiId"])

            for album in self.jellyfin_db.get_item_by_parent_id(
                *values(obj, QUEM.get_item_by_parent_album_obj)
            ):

                temp_obj = dict(obj)
                temp_obj["ParentId"] = album[1]

                if not self.album_has_album_artist(album[1], obj["KodiId"]):
                    # kofin.db parents an album to whichever of its track
                    # artists artist_discography wrote last, so "albums
                    # parented here" over-collects: a compilation lands on
                    # one arbitrary contributor, and removing that artist
                    # used to take the whole album with it. Kodi's
                    # album_artist table is the ownership test; a kept album
                    # is re-parented so the reference sweep below cannot
                    # reach it.
                    self.jellyfin_db.update_parent_id(None, album[0])
                    continue

                for song in self.jellyfin_db.get_item_by_parent_id(
                    *values(temp_obj, QUEM.get_item_by_parent_song_obj)
                ):
                    self.remove_song(song[1], obj["Id"])
                self.jellyfin_db.remove_items_by_parent_id(
                    *values(temp_obj, QUEM.delete_item_by_parent_song_obj)
                )
                self.jellyfin_db.remove_items_by_parent_id(
                    *values(temp_obj, QUEM.delete_item_by_parent_artist_obj)
                )
                self.remove_album(temp_obj["ParentId"], obj["Id"])
            self.jellyfin_db.remove_items_by_parent_id(
                *values(obj, QUEM.delete_item_by_parent_album_obj)
            )

            self.remove_artist(obj["KodiId"], obj["Id"])

            # The trigger has fired; give every still-present song the
            # artist's removal orphaned a substitute [Missing Tag] credit so
            # it stays visible, and clear its reference checksum so the next
            # walk rewrites the true credits — re-creating the artist if the
            # server still has it, and dropping the substitute.
            for song_id in self.recredit_songs(credited):
                song_jellyfin_id = self.jellyfin_db.get_item_by_kodi_id(song_id, "song")
                if song_jellyfin_id:
                    self.jellyfin_db.update_reference(None, song_jellyfin_id)

        self.jellyfin_db.remove_item(*values(obj, QUEM.delete_item_obj))

    def remove_artist(self, kodi_id, item_id):

        self.artwork.delete(kodi_id, "artist")
        self.delete(kodi_id)
        LOG.debug("DELETE artist [%s] %s", kodi_id, item_id)

    def remove_album(self, kodi_id, item_id):

        self.artwork.delete(kodi_id, "album")
        # Before delete_album, not after: tgrDeleteAlbum takes album_artist
        # with the album, and album_artist is how the discography rows are
        # found. Kodi's own trigger never touches discography (only
        # tgrDeleteArtist does), so without this the rows outlive the album.
        self.delete_album_discography(kodi_id)
        self.delete_album(kodi_id)
        LOG.debug("DELETE album [%s] %s", kodi_id, item_id)

    def remove_song(self, kodi_id, item_id):

        self.artwork.delete(kodi_id, "song")
        self.delete_song(kodi_id)
        LOG.debug("DELETE song [%s] %s", kodi_id, item_id)
