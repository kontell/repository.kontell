"""SyncPlay group membership and state mirror, ported from the fork.

Mechanical adaptations only (phase-4 plan §2): the fork's ``Jellyfin()``
client is kofin's ``Api``; ``window()`` flags become object attributes plus
the one ``player.syncplay_group_active`` write; ``translate()`` ids are
remapped to 30550+; the played-item identity comes from the service player's
claimed play state instead of the fork's played-info pipeline; HTTP 403
detection uses kofin's ``Unauthorized`` (its transport maps 401/403 there).
The dispatcher-thread ordering, the guard-flag echo suppression, the hold
choreography, and the membership lifecycle stay recognizably identical.
"""

import threading
import time
from contextlib import contextmanager
from queue import Queue
from typing import Any, Dict, List, Optional, Tuple

import xbmc
import xbmcgui

from kofin.core import contract, settings, state, toast
from kofin.core.http import JellyfinError, Unauthorized
from kofin.core.log import Logger
from kofin.syncplay import utils
from kofin.syncplay.utils import FOLLOWING, HELD, STARTABLE, Phase
from kofin.syncplay.playback import PlaybackController
from kofin.syncplay.ports import Claim, SyncPlayApi
from kofin.syncplay.providers import (
    JELLYFIN,
    ProviderRegistry,
    TemplateProvider,
    jellyfin_registry,
)
from kofin.syncplay.tempo import TempoSession
from kofin.syncplay.timesync import TimeSync

#################################################################################################

LOG = Logger(__name__)

#################################################################################################


class SyncPlayManager(object):
    """SyncPlay group membership and state mirror (SYNCPLAY.md §5, §6, §9).

    Runs in the service process. WebSocket traffic arrives through
    service/remote.py and is processed sequentially on a dispatcher thread
    so message ordering is preserved and the websocket thread is never
    blocked.
    """

    def __init__(
        self,
        api: Optional[SyncPlayApi],
        player,
        providers: Optional[ProviderRegistry] = None,
    ):
        self.api = api
        self.player = player
        # The provider seam (plan G1.1): how a queue item id becomes a
        # playing stream, and how a Kodi library id maps back to one. The
        # service injects the registry; the default keeps the constructor
        # honest for every caller that predates the seam.
        self.providers = providers if providers is not None else jellyfin_registry(api)
        # A play kofin's own pipeline did not resolve, identified from
        # outside over the public bus (SyncProvider.Claim). kofin's claim
        # always wins over it.
        self.foreign_claim: Optional[Claim] = None
        self.playback = PlaybackController(self, player)
        self.timesync: Optional[TimeSync] = None
        # Fine sync through inputstream.tempo (syncplay/tempo.py): armed at
        # group join when this member can use it, disarmed at leave.
        self.tempo_session = TempoSession(
            notify=lambda message: self._toast(message, warning=True)
        )
        self._rate_mismatch_told = False

        self.group: Optional[Dict[str, Any]] = None  # {"GroupId", "GroupName"}
        self.group_state = None
        self.members: List[Any] = []
        self.protocol_version = 1
        self.state_version = 0
        # Dedicated time-sync socket path from the server's Hello (plugin
        # binding); None = HTTP time sync only.
        self.timesync_ws_path = None
        self.ignore_wait = False

        # [(key, PlaylistItemId, provider)] mirror of the group queue
        self.queue: List[Tuple[str, str, str]] = []
        self.queue_last_update = None
        self.current_item_id = None
        self.current_playlist_item_id = None
        # Which provider owns the current queue item (SYNCPLAY.md §14.3):
        # jellyfin for plain entries, the descriptor's Provider otherwise.
        self.current_provider = JELLYFIN
        # Whether the server negotiated the ExternalContent capability
        # (§14.1); learned from Hello, server-scoped rather than group-scoped.
        self.server_external_content = False

        # idle -> loading -> waiting_ready -> synced (utils.Phase)
        self.phase = Phase.IDLE

        self.join_local_ms = 0.0
        self.last_group_id = None
        self.last_snapshot_at = 0.0
        self._last_rejoin = 0.0
        self._last_snapshot_request = 0.0
        # How long this device's loads take, smoothed; None until one is timed.
        self._load_ms = None
        self._load_started_ms = None
        # Bumped by every load so an earlier load's watchdog can tell that it
        # has been superseded; see _start_item.
        self._load_generation = 0
        self._last_ping_report = 0.0
        self._join_pending_since = 0.0
        self._pending_local_queue = False

        # A user-initiated start paused at its first instant, awaiting the
        # group echo: {"transition", "proposed", "item_id"}. "transition"
        # marks a native playlist advance (starts at 0); otherwise the
        # start position is read from the player once it settles.
        self._hold: Optional[Dict[str, Any]] = None

        self._prog_depth = 0
        self._prog_release = 0.0
        self._prog_lock = threading.Lock()

        self._inbox = Queue()  # type: Queue
        self._running = True
        self._dispatcher = threading.Thread(
            target=self._dispatch_loop, name="kofin-syncplay-dispatch"
        )
        self._dispatcher.daemon = True
        self._dispatcher.start()

    # ------------------------------------------------------------------
    # Plumbing
    # ------------------------------------------------------------------

    def stop(self):
        # The leave is a courtesy to the group, not something teardown waits
        # on: this runs on the service main thread inside Service.stop, and a
        # POST at the transport's default budget (6 s connect + 30 s read, no
        # retries, so no abort check) against a server that vanished without
        # closing the socket held teardown well past Kodi's five-second
        # script-stop grace (audit R4). Skipped outright when the service
        # already knows the server is away; otherwise sent on the short
        # budget syncplay_leave carries.
        if self.in_group() and not state.is_offline():
            try:
                self._api_raw("syncplay_leave")
            except Exception:
                pass

        self._running = False
        self._inbox.put(None)
        self._leave_locally()
        self._dispatcher.join(timeout=5)
        if self._dispatcher.is_alive():  # pragma: no cover - watchdog only
            LOG.warning("syncplay dispatcher did not stop within deadline")

    def on_notification(self, method, data):
        """Entry point from the websocket routing; returns immediately."""
        self._inbox.put((method, data))

    def _post(self, func, *args):
        """Run a callable on the dispatcher thread."""
        self._inbox.put((func, args))

    def _dispatch_loop(self):
        LOG.info("--->[ syncplay dispatcher ]")

        while self._running:
            entry = self._inbox.get()

            if entry is None:
                break

            try:
                method, data = entry

                if callable(method):
                    method(*data)
                elif method == "SyncPlayCommand":
                    self._handle_command(data)
                elif method == "SyncPlayGroupUpdate":
                    self._handle_group_update(data)
                elif method == "WebSocketConnected":
                    self._on_ws_connected()
            except Exception as error:
                LOG.exception("SyncPlay dispatch error: %s", error)

        LOG.info("---<[ syncplay dispatcher ]")

    def get_api(self) -> Optional[SyncPlayApi]:
        return self.api

    def _api(self, name, *args):
        """SyncPlay REST with the §9 reaction to a lost session (401/403 on
        kofin's transport): one rate-limited automatic re-join before
        giving up."""
        api_client = self.get_api()

        if api_client is None:
            return None

        try:
            return getattr(api_client, name)(*args)
        except Unauthorized:
            if self.in_group():
                LOG.info("SyncPlay %s unauthorized, attempting rejoin", name)
                self._post(self._attempt_rejoin)
            else:
                LOG.warning("SyncPlay %s unauthorized", name)
        except Exception as error:
            LOG.warning("SyncPlay %s failed: %s", name, error)

        return None

    def _api_raw(self, name, *args):
        """SyncPlay REST that surfaces HTTP errors to the caller."""
        api_client = self.get_api()

        if api_client is None:
            return None

        return getattr(api_client, name)(*args)

    # ------------------------------------------------------------------
    # State helpers
    # ------------------------------------------------------------------

    def in_group(self):
        return self.group is not None

    def enabled(self):
        return settings.get_bool("syncPlayEnabled")

    def offset_ms(self):
        return self.timesync.offset_ms if self.timesync else 0.0

    def server_now_ms(self):
        return utils.local_ms() + self.offset_ms()

    def server_now_iso(self):
        return utils.to_iso(self.server_now_ms())

    def join_server_ms(self):
        """Join instant on the server clock; tracks time sync refinement."""
        return self.join_local_ms + self.offset_ms()

    def get_utc_time(self):
        try:
            return self._api_raw("get_utc_time")
        except Exception as error:
            LOG.debug("GetUtcTime failed: %s", error)
            return None

    def can_ws_timesync(self):
        return self.in_group() and bool(self.timesync_ws_path)

    def timesync_ws_target(self):
        """(url, authorization) for the dedicated time-sync socket, or None."""
        if not self.timesync_ws_path:
            return None

        api_client = self.get_api()

        if api_client is None:
            return None

        return (
            api_client.websocket_url(self.timesync_ws_path),
            api_client.authorization(),
        )

    def on_timesync_update(self):
        """Report our ping after accepted measurements (SYNCPLAY.md §3)."""
        if not self.in_group() or self.timesync is None:
            return

        now = time.time()

        if now - self._last_ping_report < utils.TIMESYNC_INTERVAL - 5:
            return

        if self.timesync.ping_ms is not None:
            self._last_ping_report = now
            self._api("syncplay_ping", int(self.timesync.ping_ms))

    @contextmanager
    def programmatic(self):
        """Marks player actions we cause, so their Kodi callbacks are not
        forwarded to the group as user requests."""
        with self._prog_lock:
            self._prog_depth += 1

        try:
            yield
        finally:
            with self._prog_lock:
                self._prog_depth -= 1
                self._prog_release = time.time()

    def is_programmatic(self):
        with self._prog_lock:
            if self._prog_depth > 0:
                return True

            return (time.time() - self._prog_release) < utils.PROGRAMMATIC_ECHO_GRACE

    def _local_file_info(self) -> Optional[Claim]:
        """The claimed play state of the current kofin playback, or None.

        kofin's service player claims every play resolved through the
        plugin (kofin.play.json), so the claim *is* the identity pipeline
        the fork read from its played-info dict.
        """
        try:
            if not self.player.isPlaying():
                return None

            claim: Optional[Claim] = self.player.current_item()
            if claim:
                return claim

            # Not a kofin play: the foreign claim (public bus) is the
            # identity, when one was published.
            return self.foreign_claim
        except Exception:
            pass

        return None

    def _local_item_id(self):
        info = self._local_file_info()

        if info:
            return info.get("Id")

        return state.get_playing_id() or None

    def watching_own_media(self):
        """A spectator whose player is showing something that is not the
        group's item.

        ``ignore_wait`` alone cannot answer this. A spectator that is idle
        still follows a queue update (``_apply_play_queue``) and then needs
        the group's transport commands to start along with everyone else, so
        a guard on the flag alone would strand it paused. Comparing what is
        actually playing against the group's item separates the two without
        any state to keep in step.
        """
        if not self.ignore_wait or not self.player.isPlaying():
            return False

        local = self._local_item_id()
        own = bool(local) and local != self.current_item_id

        if not own:
            LOG.debug(
                "Spectator follows the group: playing %s, group item %s",
                local,
                self.current_item_id,
            )

        return own

    def is_transcoding(self):
        info = self._local_file_info()
        return info is not None and info.get("PlayMethod") == "Transcode"

    def current_claim(self) -> Optional[Claim]:
        """The claimed play state of the current playback, or None: what the
        fine-sync scheduler reads its route (``Tempo``) off."""
        return self._local_file_info()

    def refresh_tempo_session(self):
        """The fine-sync setting changed: arm or disarm for the current group.
        Outside a group there is nothing to do — join arms it."""
        if not self.in_group():
            return

        if settings.get_bool("syncPlayTempo"):
            self.tempo_session.begin()
        else:
            self.tempo_session.end()

    def notify_rate_mismatch(self):
        """The scheduler gave up on a residual that keeps regrowing: tell the
        user once per group, because the cause is on their side."""
        if self._rate_mismatch_told:
            return

        self._rate_mismatch_told = True
        self._toast(settings.localized(30592), warning=True)

    def reload_current_item(self):
        """Restart the current item at the group position.

        The seek path uses this where an in-stream seek cannot be accurate (a
        transcode): starting the stream at the target is exact. The start
        position comes from the drift reference, which the Seek command has
        just set, so no position needs threading through.
        """
        if not self.in_group() or self.current_item_id is None:
            return

        self._start_item(
            self.current_item_id, self.current_playlist_item_id, self.current_provider
        )

    def _load_allowance_ms(self):
        """How far ahead of the group to aim a load that is about to start.

        A load is not instant, and a playing group does not wait for it: aim at
        where the group is now and the stream starts wherever the group has got
        to by the time the first frame arrives. On direct play that is a few
        hundred milliseconds and nobody notices. On a transcode the server has
        to start encoding first, and the measured cost was ~9s — which is what
        a member looked "permanently adrift" by after a group Seek, having in
        fact loaded at exactly the position it was told.

        The allowance is measured, not predicted, because the load itself is
        what determines it: whether the server transcodes depends on the
        PlaybackInfo negotiation that happens *inside* the load. So the last
        load's duration stands in for the next one's, which converges after a
        single item on any given device.

        Zero unless the group is playing. Aiming ahead of a paused group would
        land the member past a position that is not going to move.
        """
        if self._load_ms is None or not self.playback.reference_is_playing():
            return 0.0

        return min(self._load_ms, utils.LOAD_ALLOWANCE_MAX_MS)

    def _note_load_completed(self):
        """Fold the load that just finished into the allowance."""
        started = self._load_started_ms
        self._load_started_ms = None

        if started is None:
            return

        elapsed = utils.local_ms() - started

        if (
            elapsed < utils.LOAD_ALLOWANCE_MIN_MS
            or elapsed > utils.LOAD_ALLOWANCE_MAX_MS
        ):
            # Too quick to be worth aiming off for, or so slow that something
            # other than loading happened (a dialog, a stall) and it would
            # poison the estimate.
            return

        if self._load_ms is None:
            self._load_ms = elapsed
        else:
            weight = utils.LOAD_ALLOWANCE_SMOOTHING
            self._load_ms = weight * elapsed + (1.0 - weight) * self._load_ms

        LOG.info(
            "[ syncplay/load ] took %.1fs; aiming %.1fs ahead next time",
            elapsed / 1000.0,
            self._load_ms / 1000.0,
        )

    def post_report(self, kind, position_s=None):
        """Ready/Buffering report with our actual position (SYNCPLAY.md §4).

        position_s overrides the live clock for reports that promise a
        position we are committed to landing on (a deferred audio seek).
        """
        if not self.in_group() or self.current_playlist_item_id is None:
            return

        position = position_s

        if position is None:
            try:
                position = self.player.getTime()
            except Exception:
                position = 0.0

        is_playing = self.player.isPlaying() and not xbmc.getCondVisibility(
            "Player.Paused"
        )
        self._api(
            kind,
            self.server_now_iso(),
            utils.seconds_to_ticks(position),
            bool(is_playing),
            self.current_playlist_item_id,
        )

    def _text(self, string_id, value=None):
        """localized() returns '' for unknown ids; never let formatting
        break a message handler."""
        template = settings.localized(string_id)

        if value is None:
            return template

        try:
            return template % value
        except (TypeError, ValueError):
            return "%s %s" % (template, value)

    def _toast(self, message, error=False, warning=False):
        if not settings.get_bool("syncPlayNotifications") and not (error or warning):
            return

        level = toast.ERROR if error else toast.WARNING if warning else toast.INFO
        toast.show(message, level, heading="SyncPlay", time_ms=3000)

    # ------------------------------------------------------------------
    # Group membership (menu-facing)
    # ------------------------------------------------------------------

    def list_groups(self):
        try:
            return self._api_raw("syncplay_list") or []
        except Exception as error:
            LOG.warning("SyncPlay list failed: %s", error)
            return None

    def refresh_group_info(self):
        """Refresh the member list for the menu."""
        if not self.in_group():
            return

        assert self.group is not None  # in_group() above
        for group in self.list_groups() or []:
            if group.get("GroupId") == self.group["GroupId"]:
                self.members = (
                    group.get("Members") or group.get("Participants") or self.members
                )
                self.group["GroupName"] = (
                    group.get("GroupName") or self.group["GroupName"]
                )

    def join_group(self, group_id):
        self._join_pending_since = time.time()

        try:
            # Request v2 unconditionally: older servers ignore unknown
            # fields and we detect the version from GroupJoined (§2).
            self._api_raw("syncplay_join", group_id, 2)
        except JellyfinError as error:
            LOG.warning("SyncPlay join failed: %s", error)
            self._toast(settings.localized(30578), error=True)
            return False
        except Exception as error:
            LOG.warning("SyncPlay join failed: %s", error)
            self._toast(settings.localized(30578), error=True)
            return False

        self._watch_join_feedback()
        return True

    def new_group(self, group_name):
        self._join_pending_since = time.time()
        self._pending_local_queue = True

        try:
            self._api_raw("syncplay_new", group_name, 2)
        except Exception as error:
            LOG.warning("SyncPlay new group failed: %s", error)
            self._pending_local_queue = False
            self._toast(settings.localized(30578), error=True)
            return False

        self._watch_join_feedback()
        return True

    def leave_group(self):
        try:
            self._api_raw("syncplay_leave")
        except Exception as error:
            LOG.warning("SyncPlay leave failed: %s", error)

        self._leave_locally()
        self._toast(settings.localized(30564))

    def toggle_spectator(self):
        self.ignore_wait = not self.ignore_wait
        self._api("syncplay_set_ignore_wait", self.ignore_wait)
        self._toast(
            settings.localized(30569) if self.ignore_wait else settings.localized(30583)
        )

        if not self.ignore_wait:
            # Coming back from spectator mode: re-attach so the server
            # pushes the group state again now, instead of us only
            # catching up at the group's next queue change.
            self._attempt_rejoin(force=True)

    def request_resync(self):
        """Menu 'resync': snapshot on v2, re-join on v1 (§4, §9)."""
        if not self.in_group():
            return

        if self.protocol_version >= 2:
            self._request_snapshot(force=True)
        else:
            self._attempt_rejoin(force=True)

    def _watch_join_feedback(self):
        """The feedback plane is mandatory: joining without a working
        WebSocket would mean never receiving a single command (§1)."""

        def check():
            if self.in_group() or not self._join_pending_since:
                return

            LOG.warning("No GroupJoined update within 10s of joining")
            self._toast(settings.localized(30570), error=True)

            try:
                self._api_raw("syncplay_leave")
            except Exception:
                pass

        utils.later(10, self._post, check)

    # ------------------------------------------------------------------
    # WebSocket message handling (dispatcher thread)
    # ------------------------------------------------------------------

    # Group updates by type (P2.4), in three tables that keep the dispatch's
    # guard order: what is handled whether or not we are in a group, what is
    # handled in-group before the state version moves, and what is versioned
    # and dropped when stale. Method names, not bound methods, so the fork's
    # __init__ stays as it is.
    _GROUP_UPDATES_ANY_STATE = {
        "GroupJoined": "_on_group_joined",
        "NotInGroup": "_on_not_in_group",
        "GroupDoesNotExist": "_on_not_in_group",
        "LibraryAccessDenied": "_on_library_access_denied",
    }
    _GROUP_UPDATES_UNVERSIONED = {
        "GroupLeft": "_on_group_left",
        "UserJoined": "_on_user_joined",
        "UserLeft": "_on_user_left",
    }
    _GROUP_UPDATES_VERSIONED = {
        "StateUpdate": "_on_state_update",
        "PlayQueue": "_on_play_queue",
        "StateSnapshot": "_on_state_snapshot",
        "PositionBeacon": "_on_beacon",
    }

    def _handle_group_update(self, data):
        gtype = data.get("Type")
        payload = data.get("Data")
        version = data.get("StateVersion")

        handler = self._GROUP_UPDATES_ANY_STATE.get(gtype)
        if handler is not None:
            getattr(self, handler)(payload or {}, version)
            return

        if not self.in_group():
            return
        assert self.group is not None  # in_group() above
        if data.get("GroupId") and data["GroupId"] != self.group["GroupId"]:
            return

        if gtype == "GroupLeft":
            # Before the version bookkeeping: a left group has no version.
            self._on_group_left(payload or {})
            return

        previous_version = self.state_version
        if version is not None:
            self.state_version = max(previous_version, version)

        handler = self._GROUP_UPDATES_UNVERSIONED.get(gtype)
        if handler is not None:
            getattr(self, handler)(payload or {})
            return

        if utils.is_stale_version(version, previous_version):
            LOG.info("Ignoring stale %s (v%s < v%s)", gtype, version, previous_version)
            return

        handler = self._GROUP_UPDATES_VERSIONED.get(gtype)
        if handler is None:
            LOG.debug("Unhandled group update type: %s", gtype)
            return
        getattr(self, handler)(payload or {}, version, previous_version)

    def _on_not_in_group(self, payload, version):
        if self.in_group():
            self._attempt_rejoin()

    def _on_library_access_denied(self, payload, version):
        self._toast(settings.localized(30579), error=True)

    def _on_group_left(self, payload):
        self._leave_locally()
        self._toast(settings.localized(30564))

    def _on_user_joined(self, payload):
        self._toast(self._text(30565, payload))

    def _on_user_left(self, payload):
        self._toast(self._text(30566, payload))

    def _on_state_update(self, payload, version, previous_version):
        previous = self.group_state
        self.group_state = payload.get("State")
        LOG.debug(
            "[ syncplay/state ] %s (%s)",
            self.group_state,
            payload.get("Reason"),
        )
        if self.group_state == "Waiting" and previous == "Playing":
            # A member dropped out or started buffering: the whole
            # group holds. Surface why playback froze (S4.5).
            self._toast(settings.localized(30585))

    def _on_play_queue(self, payload, version, previous_version):
        self._apply_play_queue(payload)

    def _on_state_snapshot(self, payload, version, previous_version):
        self._apply_snapshot(payload)

    def _handle_command(self, command):
        """SyncPlayCommand gating per SYNCPLAY.md §5.1."""
        if not self.in_group():
            return

        assert self.group is not None  # in_group() above
        if command.get("GroupId") and command["GroupId"] != self.group["GroupId"]:
            LOG.info("Discarding command for another group")
            return

        previous_version = self.state_version
        version = command.get("StateVersion")

        if version is not None:
            self.state_version = max(previous_version, version)

        if utils.is_stale_version(version, previous_version):
            LOG.info("Ignoring stale command (v%s < v%s)", version, previous_version)
            return

        emitted = utils.parse_iso_ms(command.get("EmittedAt"))

        if emitted is not None and emitted < self.join_server_ms() - 2000:
            LOG.info("Discarding command emitted before our join")
            return

        if self.watching_own_media():
            # _apply_play_queue already refuses to let the group's queue tear
            # down a spectator's own playback; the transport commands had no
            # such guard, so a group Seek or Unpause still landed on it.
            # Measured: a spectator at 422.5s of its own item was seeked to
            # 209.6s by the group's next command.
            LOG.info("Spectator playing own media; not following transport")
            return

        if (
            command.get("Command") != "Stop"
            and command.get("PlaylistItemId")
            and command["PlaylistItemId"] != self.current_playlist_item_id
        ):
            LOG.info(
                "Command for another queue item (%s != %s)",
                command.get("PlaylistItemId"),
                self.current_playlist_item_id,
            )

            if self.protocol_version >= 2:
                # A command for an item we don't have means we missed a
                # queue update: reconcile instead of staying split (§6).
                self._request_snapshot()

            return

        self.playback.schedule(command)

    def _on_group_joined(self, info, version):
        if not self.enabled():
            LOG.info("SyncPlay is disabled in settings, ignoring GroupJoined")
            return

        group = self.group  # in_group() is exactly this None test
        rejoined = group is not None and group["GroupId"] == info.get("GroupId")

        self.group = {
            "GroupId": info.get("GroupId"),
            "GroupName": info.get("GroupName") or "",
        }
        self.last_group_id = info.get("GroupId")
        self.group_state = info.get("State")
        # Members (with per-member state) is a v2/phase-0 field; stock v1
        # servers only send Participants name strings.
        self.members = info.get("Members") or info.get("Participants") or []
        server_version = info.get("ProtocolVersion") or 1
        self.protocol_version = 2 if server_version >= 2 else 1
        self.state_version = version or 0
        self.queue_last_update = None
        self.join_local_ms = utils.local_ms()
        self._join_pending_since = 0.0

        if not rejoined:
            # Spectator state is client-local — the wire's Members carry no
            # session identity, so there is nothing to read it back from — and
            # a GroupJoined for the group we are already in would otherwise
            # silently undo the user's choice. Measured: a spectator toggle 3s
            # into a hot join was reset by the join's own update, and the
            # group went on driving that member's private playback.
            self.ignore_wait = False

        # The phase-3 stub is now driven: while True, Play Next and the
        # cinema/near-end prompts are withheld (the group queue is
        # authoritative).
        self.player.syncplay_group_active = True

        if self.timesync is None:
            self.timesync = TimeSync(self)
            self.timesync.start()
        else:
            self.timesync.force_update()

        self.playback.start_loop()

        if not rejoined:
            self._rate_mismatch_told = False
            self.tempo_session.begin()

        LOG.info(
            "--->[ syncplay group/%s ] protocol v%s",
            self.group["GroupId"],
            self.protocol_version,
        )

        if self.protocol_version >= 2 and self.timesync_ws_path is None:
            # Learn the time-sync transport (plugin binding); integrated v2
            # servers have no Hello and stay on HTTP time sync.
            self._hello()

        if not rejoined:
            self._toast(self._text(30563, self.group["GroupName"] or "?"))

        if self._pending_local_queue:
            self._pending_local_queue = False
            self._post(self._forward_local_play)

        self.publish_session_state(announce=True)

    def _leave_locally(self):
        if not self.in_group() and self.phase == Phase.IDLE:
            return

        self.playback.stop_loop()
        self.tempo_session.end()

        if self.timesync is not None:
            self.timesync.stop()
            self.timesync = None

        self.group = None
        self.group_state = None
        self.members = []
        self.protocol_version = 1
        self.state_version = 0
        self.queue = []
        self.queue_last_update = None
        self.current_item_id = None
        self.current_playlist_item_id = None
        self.current_provider = JELLYFIN
        self.phase = Phase.IDLE
        self.ignore_wait = False
        self._join_pending_since = 0.0
        self.player.syncplay_group_active = False
        self._release_hold()
        self.publish_session_state(announce=True)
        LOG.info("---<[ syncplay group ]")

    def _attempt_rejoin(self, force=False):
        """§9: one automatic re-join before surfacing an error."""
        if not self.last_group_id:
            self._leave_locally()
            return

        now = time.time()

        if not force and now - self._last_rejoin < utils.AUTO_REJOIN_INTERVAL:
            return

        self._last_rejoin = now
        LOG.info("Attempting SyncPlay rejoin of %s", self.last_group_id)

        try:
            self._api_raw("syncplay_join", self.last_group_id, 2)
        except Exception as error:
            LOG.warning("SyncPlay rejoin failed: %s", error)
            self._leave_locally()
            self._toast(settings.localized(30571), warning=True)

    def _request_snapshot(self, force=False):
        """§6: reconcile via a pushed StateSnapshot, rate-limited."""
        if self.protocol_version < 2:
            return

        now = time.time()

        if (
            not force
            and now - self._last_snapshot_request < utils.SNAPSHOT_REQUEST_INTERVAL
        ):
            return

        self._last_snapshot_request = now
        self._api("syncplay_snapshot")

    def _hello(self):
        """Capability probe (plugin binding): learns the dedicated time-sync
        socket path and registers our protocol version for this device.
        Stock and integrated servers 404 — HTTP time sync stays in place and
        nothing else changes."""
        try:
            # Declared because the engine honours it: a descriptor entry is
            # resolved through the provider registry, and one no provider
            # answers is a graceful load failure, exactly as §14.4 requires.
            info = self._api_raw("syncplay_hello", 2, ["ExternalContent"]) or {}
        except Unauthorized:
            return
        except JellyfinError as error:
            LOG.debug("SyncPlay hello unavailable: %s", error)
            self.timesync_ws_path = None
            return
        except Exception as error:
            LOG.debug("SyncPlay hello failed: %s", error)
            return

        self.timesync_ws_path = (info.get("TimeSync") or {}).get("WebSocketPath")
        self.server_external_content = "ExternalContent" in (
            info.get("Capabilities") or []
        )

        if self.server_external_content:
            LOG.info("SyncPlay server accepts external content")

        if self.timesync_ws_path:
            LOG.info("SyncPlay time-sync socket at %s", self.timesync_ws_path)

    def _on_ws_connected(self):
        """Reconnect contract (§9): a v2 server re-attaches the member and
        pushes a StateSnapshot on its own; verify and pull one if it never
        arrives. v1 servers end the session on any socket close (report R2):
        probe GET /SyncPlay/List and re-join, or stop pretending."""
        if not self.in_group():
            return

        if self.timesync is not None:
            self.timesync.force_update()

        if self.protocol_version >= 2:
            connected_at = time.time()

            def check():
                if self.in_group() and self.last_snapshot_at < connected_at:
                    LOG.info("No snapshot pushed after reconnect, requesting one")
                    self._request_snapshot()

            utils.later(5, self._post, check)
        else:
            self._kicked_probe()

    def _kicked_probe(self):
        groups = self.list_groups()

        if groups is None:
            # Server unreachable right now; the next reconnect re-probes.
            LOG.debug("kicked-probe skipped: group list unavailable")
            return

        group = self.group  # in_group() is exactly this None test
        group_id = group["GroupId"] if group is not None else self.last_group_id

        if any(group.get("GroupId") == group_id for group in groups):
            self._attempt_rejoin(force=True)
            return

        LOG.info("Group %s no longer exists after reconnect", group_id)
        self._leave_locally()
        self._toast(settings.localized(30571), warning=True)

    # ------------------------------------------------------------------
    # Snapshots and beacons (v2)
    # ------------------------------------------------------------------

    def _apply_snapshot(self, snapshot):
        """§5.4: equivalent to GroupJoined + PlayQueue + a synthetic command."""
        self.last_snapshot_at = time.time()

        if snapshot.get("GroupName"):
            assert self.group is not None  # snapshots only arrive in-group
            self.group["GroupName"] = snapshot["GroupName"]

        self.group_state = snapshot.get("State")
        self.members = snapshot.get("Members") or self.members

        self._apply_play_queue(snapshot.get("PlayQueue") or {})

        if self.phase == Phase.LOADING:
            # The queue application is (re)loading the item; the ready
            # flow will converge on the snapshot position by itself.
            return

        state = snapshot.get("State")

        if snapshot.get("IsPlaying"):
            command = "Unpause"
        elif state == "Idle":
            command = "Stop"
        else:
            command = "Pause"

        self._handle_command(
            {
                "Command": command,
                "When": snapshot.get("When"),
                "EmittedAt": snapshot.get("When"),
                "PositionTicks": snapshot.get("PositionTicks") or 0,
                "PlaylistItemId": self.current_playlist_item_id,
                "StateVersion": None,
            }
        )

    def _on_beacon(self, beacon, version, previous_version):
        """§11: advisory position data; §6: version gap detection."""
        if version is not None and previous_version and version > previous_version:
            LOG.info(
                "Beacon v%s ahead of last update v%s, requesting snapshot",
                version,
                previous_version,
            )
            self._request_snapshot()

        if (
            beacon.get("PlaylistItemId")
            and beacon["PlaylistItemId"] == self.current_playlist_item_id
        ):
            when_ms = utils.parse_iso_ms(beacon.get("When"))

            if when_ms is not None:
                self.playback.set_reference(
                    beacon.get("PositionTicks") or 0, when_ms, True
                )

    # ------------------------------------------------------------------
    # Queue mirror (SYNCPLAY.md §5.3, report §9.5.1)
    # ------------------------------------------------------------------

    def _apply_play_queue(self, data):
        last_update = utils.parse_iso_ms(data.get("LastUpdate"))

        if (
            last_update is not None
            and self.queue_last_update is not None
            and last_update <= self.queue_last_update
        ):
            LOG.debug("Ignoring play queue not newer than the applied one")
            return

        self.queue_last_update = last_update
        playlist = data.get("Playlist") or []
        self.queue = [self._queue_entry(entry) for entry in playlist]
        index = data.get("PlayingItemIndex", -1)
        is_playing = bool(data.get("IsPlaying"))
        start_ticks = data.get("StartPositionTicks") or 0

        LOG.info(
            "[ syncplay/queue ] %s items, playing %s (%s)",
            len(self.queue),
            index,
            data.get("Reason"),
        )

        if index is None or index < 0 or index >= len(self.queue):
            self._detach_playback(stop_media=True)
            return

        item_id, playlist_item_id, provider = self.queue[index]

        if (
            playlist_item_id == self.current_playlist_item_id
            and self.phase != Phase.IDLE
        ):
            return  # tail-only change; drift reference stays authoritative

        # Position reference: StartPositionTicks is extrapolated to *send* time
        # by the server (Group.cs::GetPlayQueueUpdate adds the elapsed since
        # LastActivity), so the instant it describes is now — not LastUpdate,
        # which timestamps the *queue's* last change and, on a group that has
        # been playing a while, is arbitrarily far in the past.
        #
        # Pairing the two added the whole elapsed playback a second time, so a
        # member cold-joining a Playing group started at the group position
        # plus elapsed-since-the-queue-changed: measured 27.0s against a group
        # at 11.2s, and 546.0s against a group at 271.6s. The beacons then
        # corrected it, so the visible symptom was the joiner starting far
        # ahead and cutting backwards by the difference.
        #
        # last_update keeps its real job: the queue-version dedup above.
        reference_ms = self.server_now_ms()
        self.playback.set_reference(start_ticks, reference_ms, is_playing)

        held = self._hold
        held_match = held is not None and held.get("item_id") == item_id

        if (
            item_id
            and self.player.isPlaying()
            and (item_id == self._local_item_id() or held_match)
        ):
            # We are already playing this exact item (e.g. the queue we
            # just proposed with SetNewQueue came back with a fresh
            # PlaylistItemId): adopt it. Never tear down and reload media
            # that is already on screen, regardless of phase. A held start
            # matches on the id we proposed, since the play pipeline may
            # not have claimed the new item yet.
            LOG.info("Adopting queue identity for the playing item")
            self._hold = None
            self.current_item_id = item_id
            self.current_playlist_item_id = playlist_item_id
            self.current_provider = provider
            self.phase = Phase.WAITING_READY
            self.playback.ensure_paused()
            self._post(self.playback.prepare_ready)
            self.publish_session_state()
            return

        if self.ignore_wait and self.player.isPlaying():
            # A spectator watching their own thing: the group's queue
            # must not tear it down. They re-attach via the menu (or
            # automatically once their player is idle again).
            LOG.info("Spectator playing own media; not following the queue")
            return

        self._start_item(item_id, playlist_item_id, provider)

    @staticmethod
    def _queue_entry(entry):
        """(key, PlaylistItemId, provider) for one wire playlist entry.

        A descriptor entry (SYNCPLAY.md §14.3) is identified by its
        Provider:Key; the ItemId beside it is a server-side sentinel and
        never a client-side identity — claims carry the key, so every
        comparison against _local_item_id keeps working unchanged.
        """
        content = entry.get("Content")

        if isinstance(content, dict) and content.get("Key"):
            return (
                content["Key"],
                entry.get("PlaylistItemId"),
                content.get("Provider") or JELLYFIN,
            )

        return (entry.get("ItemId"), entry.get("PlaylistItemId"), JELLYFIN)

    def _start_item(self, item_id, playlist_item_id, provider=JELLYFIN):
        if not self.in_group():  # left while this update was in flight
            return

        self.phase = Phase.LOADING
        self.current_item_id = item_id
        self.current_playlist_item_id = playlist_item_id
        self.current_provider = provider

        estimate_ms = self.playback.estimate_position_ms() or 0
        allowance_ms = self._load_allowance_ms()
        estimate_ms += allowance_ms
        self._load_started_ms = utils.local_ms()

        LOG.info(
            "[ syncplay/play ] %s (%s) at %.1fs%s",
            item_id,
            playlist_item_id,
            estimate_ms / 1000.0,
            (
                " (+%.1fs load allowance)" % (allowance_ms / 1000.0)
                if allowance_ms
                else ""
            ),
        )

        try:
            # Through the provider seam, which reaches the client directly
            # rather than via _api: a 403 here is a library permission
            # problem, not lost group membership.
            target = self.providers.play_target(
                item_id, utils.ms_to_ticks(estimate_ms), provider=provider
            )
        except Exception as error:
            LOG.warning("SyncPlay item lookup failed: %s", error)
            self._load_failed("item lookup failed")
            return

        try:
            self.playback.play_item(target)
        except Exception as error:
            LOG.exception("SyncPlay playback start failed: %s", error)
            self._load_failed(error)
            return

        # Identify the load, not the item. A transcode seek reloads the *same*
        # playlist item, so "still loading, and still the item I armed for" is
        # true for a later load as well as a stuck one -- and the watchdog from
        # a load that succeeded 45s ago would fire into a healthy reload and
        # leave the group. Measured: a group start at 12:59:37 killed the
        # reload from a seek at 13:00:19, and the member dropped out mid-test.
        self._load_generation += 1
        generation = self._load_generation

        def check():
            if self.phase == Phase.LOADING and self._load_generation == generation:
                self._load_failed("no playback within 45s")

        utils.later(45, self._post, check)
        self.publish_session_state()

    def _load_failed(self, reason):
        LOG.warning("SyncPlay could not start playback: %s", reason)
        self._toast(settings.localized(30576), error=True)

        try:
            self._api_raw("syncplay_leave")
        except Exception:
            pass

        self._leave_locally()

    def _detach_playback(self, stop_media=False):
        was_active = self.phase != Phase.IDLE
        self._hold = None
        self.current_item_id = None
        self.current_playlist_item_id = None
        self.phase = Phase.IDLE
        self.playback.cancel_pending()
        self.playback.last_command = None

        # Only kill media that SyncPlay itself is driving: joining an
        # idle group must not stop whatever the user was watching.
        if stop_media and was_active:
            self.playback.stop_media()

        self.publish_session_state()

    def on_group_stopped(self):
        """A Stop command was executed."""
        self.current_item_id = None
        self.current_playlist_item_id = None
        self.phase = Phase.IDLE
        self.publish_session_state()

    def on_local_unpaused(self):
        """An Unpause command was executed against loaded media."""
        if self.phase in HELD:
            self.phase = Phase.SYNCED
            self.publish_session_state()

    # ------------------------------------------------------------------
    # Player events (called from service/player.py hooks)
    # ------------------------------------------------------------------

    def on_playback_started(self):
        """Earliest signal of a local item start, before A/V rolls.

        Runs on the player callback thread the instant playback begins
        (including a native playlist advance), so a start that must wait
        for the group is paused before it plays audibly rather than a few
        seconds in when the round trip completes.
        """
        if not self.in_group():
            return

        if self.phase == Phase.LOADING:
            # Our own play_item(): try to hold before the first frame;
            # on_avstarted re-ensures once the player is fully up.
            self.playback.ensure_paused()
            return

        if self.is_programmatic():
            return

        if self.ignore_wait:
            # A spectator's own plays stay local: nothing is proposed to
            # the group, so there is nothing to hold (or demote) either.
            return

        if self.phase in STARTABLE:
            # Phase "synced" means no stop intervened since the synced
            # item: a native playlist advance, which starts at 0. Phase
            # "idle" is a fresh user start (possibly at a resume point).
            hold = {
                "transition": self.phase == Phase.SYNCED,
                "proposed": False,
                "item_id": None,
            }
            self._hold = hold
            self.playback.ensure_paused()
            self._watch_hold(hold)

    def on_kodi_play(self, data):
        """Player.OnPlay from the Kodi bus: carries the Kodi library id,
        the earliest identification of a local start (before the play
        pipeline claims the item). Called on the notification thread."""
        self._post(self._identify_held_play, data)

    def on_avstarted(self):
        if not self.in_group():
            return

        if self.phase == Phase.LOADING:
            # Hold the first frame; the group start is choreographed by
            # the server once every member reports Ready.
            self._note_load_completed()
            self.playback.ensure_paused()
            self.phase = Phase.WAITING_READY
            self._post(self.playback.prepare_ready)
            return

        if self.ignore_wait:
            return  # a spectator's own plays are not forwarded

        hold = self._hold

        if hold is not None and not hold["proposed"]:
            # The early pause is best-effort while the player is still
            # opening; with A/V up it always lands. Our own pause above
            # must not swallow the forward via the programmatic grace.
            self.playback.ensure_paused()
            self._post(self._forward_local_play)
            return

        if not self.is_programmatic() and self.phase in STARTABLE:
            self._post(self._forward_local_play)

    def on_paused(self):
        if not self.in_group() or self.is_programmatic():
            return

        if self.phase == Phase.SYNCED:
            LOG.info("[ syncplay/user pause ]")
            self._post(self._api, "syncplay_pause")

    def on_resumed(self):
        if not self.in_group() or self.is_programmatic():
            return

        if self.phase in FOLLOWING:
            LOG.info("[ syncplay/user unpause ]")
            # The group start time is the server's call: hold position
            # and ask for a group unpause instead of running ahead.
            self.playback.ensure_paused()
            self._post(self._api, "syncplay_unpause")

    def on_seek(self, seconds):
        if not self.in_group() or self.is_programmatic():
            return

        if self.phase in FOLLOWING:
            LOG.info("[ syncplay/user seek ] %.1fs", seconds)
            self._post(self._api, "syncplay_seek", utils.seconds_to_ticks(seconds))

    def on_stopped(self):
        self.foreign_claim = None  # claims are playback-scoped
        self._hold = None  # whatever was held is gone

        if not self.in_group() or self.is_programmatic():
            return

        if self.phase == Phase.LOADING:
            return  # load-failure timer handles it

        if self.phase in FOLLOWING:
            self._detach_playback()
            thread = threading.Thread(target=self._user_stopped_prompt)
            thread.daemon = True
            thread.start()

    def on_ended(self):
        self.foreign_claim = None  # claims are playback-scoped
        self._hold = None

        if not self.in_group() or self.is_programmatic():
            return

        if self.phase != Phase.SYNCED:
            return

        playlist_item_id = self.current_playlist_item_id
        self.phase = Phase.IDLE

        if playlist_item_id:
            LOG.info("[ syncplay/next item ]")
            self._post(self._api, "syncplay_next_item", playlist_item_id)

    def on_error(self):
        if not self.in_group():
            return

        LOG.warning("Playback error while in a SyncPlay group")
        self._detach_playback()
        self.ignore_wait = True
        self._post(self._api, "syncplay_set_ignore_wait", True)
        self._toast(settings.localized(30576), error=True)

    def _stop_superseded(self):
        """Did another local start (or a group item) replace the stop?"""
        return (
            self._hold is not None
            or self.phase != Phase.IDLE
            or self.player.isPlaying()
        )

    def _user_stopped_prompt(self):
        """Local stop while synced: sort out what it means for the group.

        A stop that is immediately followed by another local start is a
        replace-play (the user picked a new item), not a departure: give
        the new start a moment to appear and skip the prompt when it does.
        """
        deadline = time.time() + utils.STOP_PROMPT_GRACE

        while time.time() < deadline:
            if not self.in_group() or self._stop_superseded():
                return

            time.sleep(utils.STOP_PROMPT_POLL)

        if not self.in_group() or self._stop_superseded():
            return

        selection = xbmcgui.Dialog().select(
            settings.localized(30568),
            [
                settings.localized(30584),
                settings.localized(30580),
                settings.localized(30562),
            ],
        )

        if selection == 2:
            self.leave_group()
            return

        if not self.in_group() or self._stop_superseded():
            # Answered against a stale premise (something started while
            # the dialog was open): only an explicit leave still applies.
            return

        if selection == 0:
            # Stop playback for the whole group. Membership is kept, so
            # whatever is played next is proposed to everyone.
            self._api("syncplay_stop")
        else:
            # Explicit spectator choice — or the dialog was dismissed:
            # never leave the group silently waiting on this member.
            self.ignore_wait = True
            self._api("syncplay_set_ignore_wait", True)
            self._toast(settings.localized(30569))

    def _forward_local_play(self, attempt=0):
        """Propose the currently-playing item to the group as its queue."""
        if not self.player.isPlaying():
            # Nothing to propose — e.g. a group created before playback
            # starts. Stay idle and wait for the user to play something;
            # do not demote to spectator.
            return

        hold = self._hold

        if hold is not None and hold["proposed"]:
            return  # the fast identification path already proposed

        if hold is not None and hold["transition"]:
            # Mid-transition the playing-id window property can still name
            # the previous track; only trust the claimed play state, which
            # is keyed by the new file.
            info = self._local_file_info()
            item_id = info.get("Id") if info else None
        else:
            item_id = self._local_item_id()

        if item_id and item_id == self.current_item_id and self.phase in FOLLOWING:
            # Already the group's current item: a late-delivered start
            # event for a proposal whose echo was adopted meanwhile.
            return

        if not item_id:
            # The plugin play worker may still be resolving the item.
            if attempt >= utils.FORWARD_RETRY_LIMIT:
                self._unmanaged_local_play()
                return

            utils.later(
                utils.FORWARD_RETRY_INTERVAL,
                self._post,
                self._forward_local_play,
                attempt + 1,
            )
            return

        info = self._local_file_info() or {}
        provider = info.get("Provider") or JELLYFIN

        if hold is not None:
            hold["proposed"] = True
            hold["item_id"] = item_id

            if hold["transition"]:
                self._propose_queue(item_id, position=0.0, provider=provider)
                return

        self._propose_queue(item_id, provider=provider)

    def _identify_held_play(self, data):
        """Identify a held playlist advance from the Player.OnPlay payload.

        The Kodi library id maps straight to a provider key (for Jellyfin,
        kofin.db), so a transition can be proposed within milliseconds of the
        boundary instead of waiting for the play pipeline's claim. Fresh
        starts keep waiting for the player: their start position (a resume
        point) is only trustworthy once A/V is up.
        """
        hold = self._hold

        if not self.in_group() or hold is None or hold["proposed"]:
            return

        item = data.get("item") or {}
        kodi_id = item.get("id")
        media = item.get("type")

        if not kodi_id or kodi_id == -1 or not media:
            return

        try:
            mapped = self.providers.resolve_kodi_id(kodi_id, media)
        except Exception as error:
            LOG.warning("SyncPlay kodi id lookup failed: %s", error)
            return

        if not mapped:
            # A Kodi library item with no provider mapping: the group
            # cannot follow it, and the play pipeline (same mapping) will
            # not identify it either. Let it play now rather than after
            # the retry window.
            self._unmanaged_local_play()
            return

        if not hold["transition"]:
            return

        hold["proposed"] = True
        hold["item_id"] = mapped
        self._propose_queue(mapped, position=0.0)

    def _unmanaged_local_play(self):
        """Playing something the group can't follow (a local file,
        another addon): give playback back and stop pretending to be
        synchronized. Quiet when already a spectator — repeat plays of
        unmanaged media must not re-toast on every start."""
        self._release_hold()
        self._detach_playback()

        if self.ignore_wait:
            return

        LOG.info("Unmanaged playback while in a group, detaching")
        self.ignore_wait = True
        self._api("syncplay_set_ignore_wait", True)
        self._toast(settings.localized(30569))

    def _watch_hold(self, hold):
        """A held start that never gets adopted must not stay paused
        forever (e.g. the proposal failed): give playback back."""

        def check():
            if self._hold is not hold:
                return

            LOG.warning("Held start was never adopted; releasing the hold")
            self._release_hold()

        utils.later(utils.HOLD_RELEASE_TIMEOUT, self._post, check)

    def _release_hold(self):
        if self._hold is None:
            return

        self._hold = None
        self.playback.ensure_playing()

    def _propose_queue(self, item_id, position=None, provider=JELLYFIN, content=None):
        """Propose a queue; a held transition proposes 0 and the player is
        aligned on it at adopt time (prepare_ready), not here.

        A foreign provider's item goes out as an external-content entry
        (SYNCPLAY.md §14.2) — descriptor built from ``content`` when the
        caller has one (the bus propose), from the claim otherwise — and
        only when the server negotiated the capability: refused loudly
        rather than sent as a key the server would reject for everyone.

        External players cannot reach this path: kofin has no play-with
        flow, and the SyncPlay root entry is hidden when a
        playercorefactory override is installed (plugin/browse.py).
        """
        if position is None:
            try:
                position = self.player.getTime()
            except Exception:
                position = 0.0

        if provider != JELLYFIN:
            if not self.server_external_content:
                LOG.warning(
                    "Propose for provider %r needs the server's "
                    "ExternalContent capability; refused",
                    provider,
                )
                return

            if content is None:
                info = self._local_file_info() or {}
                content = {
                    "Provider": provider,
                    "Key": item_id,
                    "Name": info.get("Name") or "",
                    "RunTimeTicks": int(info.get("RunTimeTicks") or 0),
                }

            LOG.info(
                "[ syncplay/set queue ] %s:%s at %.1fs", provider, item_id, position
            )
            self._api(
                "syncplay_set_new_queue_ex",
                [{"Content": content}],
                0,
                utils.seconds_to_ticks(position),
            )
            return

        LOG.info("[ syncplay/set queue ] %s at %.1fs", item_id, position)
        self._api(
            "syncplay_set_new_queue",
            [item_id],
            0,
            utils.seconds_to_ticks(position),
        )

    # ------------------------------------------------------------------
    # The public provider contract (plan G2)
    # ------------------------------------------------------------------

    def on_foreign_claim(self, claim):
        """SyncProvider.Claim: what is playing when kofin's own pipeline
        did not resolve it. Called on the notification thread; applied on
        the dispatcher."""
        self._post(self._set_foreign_claim, claim)

    def _set_foreign_claim(self, claim):
        self.foreign_claim = claim
        LOG.info(
            "[ syncplay/claim ] foreign: %s via %s",
            claim.get("Id"),
            claim.get("Provider"),
        )

    def on_provider_register(self, sender, payload):
        """SyncProvider.Register: wrap the play template as a provider.

        Re-registration replaces — providers answer every service announce
        (SyncSession.State), so the registry rebuilds itself across service
        generations with no persistence anywhere.
        """
        play = contract.register_template(payload)

        if play is None:
            LOG.info("Register from %s without a usable play template", sender)
            return

        name = payload["provider"]

        if name == JELLYFIN:
            LOG.warning("Register from %s tried to replace %r", sender, JELLYFIN)
            return

        self.providers.register(
            name, TemplateProvider(play["url_template"], play["audio"])
        )
        LOG.info("[ syncplay/provider ] %r registered by %s", name, sender)

    def on_propose(self, payload):
        """SyncSession.Propose: a provider asks for its item as the group
        queue — the programmatic form of the hold-and-propose flow."""
        self._post(self._propose_from_bus, payload)

    def _propose_from_bus(self, payload):
        if not self.in_group():
            LOG.info(
                "Propose from %r outside a group; ignored", payload.get("provider")
            )
            return

        position = utils.ticks_to_seconds(payload.get("position_ticks") or 0)
        provider = payload.get("provider") or JELLYFIN

        content = None
        if provider != JELLYFIN:
            name = payload.get("name")
            try:
                runtime = int(payload.get("runtime_ticks") or 0)
            except (TypeError, ValueError):
                runtime = 0
            content = {
                "Provider": provider,
                "Key": payload["key"],
                "Name": name[:256] if isinstance(name, str) else "",
                "RunTimeTicks": max(0, runtime),
            }

        self._propose_queue(
            payload["key"], position=position, provider=provider, content=content
        )

    def publish_session_state(self, announce=False):
        """The public session mirror (plan G2.2) on ``syncsession.state``.

        ``announce`` also pings SyncSession.State over the bus — group
        join/leave and service start, which is what tells providers to
        (re)register; every other publish is property-only so the bus
        stays quiet through ordinary phase traffic.
        """
        names = []

        for member in self.members or []:
            if isinstance(member, dict):
                names.append(member.get("UserName") or "?")
            else:
                names.append("%s" % member)

        current = None

        if self.current_item_id:
            info = self._local_file_info() or {}
            current = {
                "provider": info.get("Provider") or JELLYFIN,
                "key": self.current_item_id,
            }

        state.publish_syncsession(
            {
                "v": contract.VERSION,
                "in_group": self.in_group(),
                "group_name": (self.group or {}).get("GroupName") or "",
                "members": names,
                "phase": str(self.phase),
                "current": current,
            }
        )

        if announce:
            try:
                contract.publish_state()
            except Exception as error:  # never let the bus break the engine
                LOG.warning("SyncSession.State announce failed: %s", error)

    # ------------------------------------------------------------------
    # Lifecycle from the service
    # ------------------------------------------------------------------

    def on_sleep(self):
        self.playback.cancel_pending()

    def on_wake(self):
        """Screensaver deactivate / system wake: never trust a stale clock
        offset (report §9.5.6), and reconcile the group — after a sleep the
        socket may be a zombie. A v2 snapshot request also re-attaches the
        membership server-side; v1 keeps the kicked-probe."""
        if self.timesync is not None:
            self.timesync.force_update(reset=True)

        if not self.in_group():
            return

        if self.protocol_version >= 2:
            self._post(self._request_snapshot, True)
        else:
            self._post(self._kicked_probe)
