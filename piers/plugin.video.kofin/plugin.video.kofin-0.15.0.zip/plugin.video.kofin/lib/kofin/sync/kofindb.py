# -*- coding: utf-8 -*-
"""Accessors for the kofin.db mapping tables (fork ``jellyfin_db.py`` port).

The class keeps the fork's name so the transplanted writers stay
recognizably identical (plan §2: renaming buys nothing, costs diff-ability).
"""

from collections import namedtuple

from kofin.core.log import Logger
from kofin.sync import queries_map as QU

LOG = Logger(__name__)


def sqlite_namedtuple_factory(cursor, row):
    """
    Usage:
    con.row_factory = namedtuple_factory

    http://peter-hoffmann.com/2010/python-sqlite-namedtuple-factory.html
    """
    fields = [col[0] for col in cursor.description]
    Row = namedtuple("Row", fields)
    return Row(*row)


class JellyfinDatabase:

    def __init__(self, cursor):
        self.cursor = cursor
        cursor.row_factory = sqlite_namedtuple_factory

    def get_item_by_id(self, *args):
        self.cursor.execute(QU.get_item, args)

        return self.cursor.fetchone()

    def add_reference(self, *args):
        # A NULL checksum means "re-verify every walk" — correct for
        # memberless boxsets (the V6 rule) and a field-list bug for anything
        # else: the caller downloaded this item without its Etag
        # (healing-loops-plan F4). Loud, so the offending Fields list is one
        # grep away instead of surfacing as per-walk rewrite churn.
        if args[7] is None and args[4] != "BoxSet":
            LOG.warning(
                "reference %s (%s) stamped without an Etag; it will rewrite "
                "on every walk until one arrives",
                args[0],
                args[4],
            )

        self.cursor.execute(QU.add_reference, args)

    def update_reference(self, *args):
        if args[0] is None:
            # Same rule as add_reference; no boxset exemption because
            # boxsets stamp through add_reference only.
            LOG.warning(
                "reference %s checksum cleared; it will rewrite on every "
                "walk until an Etag arrives",
                args[1],
            )

        self.cursor.execute(QU.update_reference, args)

    def update_parent_id(self, *args):
        """Parent_id is the parent Kodi id."""
        self.cursor.execute(QU.update_parent, args)

    def get_item_id_by_parent_id(self, *args):
        self.cursor.execute(QU.get_item_id_by_parent, args)

        return self.cursor.fetchall()

    def get_item_by_parent_id(self, *args):
        self.cursor.execute(QU.get_item_by_parent, args)

        return self.cursor.fetchall()

    def get_item_by_media_folder(self, *args):
        self.cursor.execute(QU.get_item_by_media_folder, args)

        return self.cursor.fetchall()

    def get_item_by_wild_id(self, item_id):
        self.cursor.execute(QU.get_item_by_wild, (item_id + "%",))

        return self.cursor.fetchall()

    def get_checksum(self, *args):
        self.cursor.execute(QU.get_checksum, args)

        return self.cursor.fetchall()

    def get_boxset_state(self, *args):
        """linked_count stamped at the set's last successful membership
        pass, or None when never stamped (docs/boxsets-robustness-plan.md).
        """
        self.cursor.execute(QU.get_boxset_state, args)

        try:
            return self.cursor.fetchone()[0]
        except TypeError:
            return

    def get_boxset_states(self):
        self.cursor.execute(QU.get_boxset_states)

        return self.cursor.fetchall()

    def add_boxset_state(self, *args):
        self.cursor.execute(QU.add_boxset_state, args)

    def remove_boxset_state(self, *args):
        self.cursor.execute(QU.delete_boxset_state, args)

    def remove_boxset_states(self):
        self.cursor.execute(QU.delete_boxset_states)

    def get_item_by_kodi_id(self, *args):

        try:
            self.cursor.execute(QU.get_item_by_kodi, args)

            return self.cursor.fetchone()[0]
        except TypeError:
            return

    def get_episode_kodi_parent_path_id(self, *args):

        try:
            self.cursor.execute(QU.get_episode_kodi_parent_path_id, args)

            return self.cursor.fetchone()[0]
        except TypeError:
            return

    def get_full_item_by_kodi_id(self, *args):

        try:
            self.cursor.execute(QU.get_item_by_kodi, args)

            return self.cursor.fetchone()
        except TypeError:
            return

    def get_media_by_id(self, *args):

        try:
            self.cursor.execute(QU.get_media_by_id, args)

            return self.cursor.fetchone()[0]
        except TypeError:
            return

    def get_media_by_parent_id(self, *args):
        self.cursor.execute(QU.get_media_by_parent_id, args)

        return self.cursor.fetchall()

    def remove_item(self, *args):
        self.cursor.execute(QU.delete_item, args)

    def remove_items_by_parent_id(self, *args):
        self.cursor.execute(QU.delete_item_by_parent, args)

    def remove_item_by_kodi_id(self, *args):
        self.cursor.execute(QU.delete_item_by_kodi, args)

    def remove_item_alias_by_kodi_id(self, *args):
        """Drop other references to one Kodi row, keeping the id given last."""
        self.cursor.execute(QU.delete_item_alias_by_kodi, args)

    def update_media_folder(self, *args):
        self.cursor.execute(QU.update_media_folder, args)

    def remove_wild_item(self, item_id):
        self.cursor.execute(QU.delete_item_by_wild, (item_id + "%",))

    def get_view_name(self, item_id):

        self.cursor.execute(QU.get_view_name, (item_id,))

        return self.cursor.fetchone()[0]

    def get_view(self, *args):

        try:
            self.cursor.execute(QU.get_view, args)

            return self.cursor.fetchone()
        except TypeError:
            return

    def add_view(self, *args):
        self.cursor.execute(QU.add_view, args)

    def remove_view(self, *args):
        self.cursor.execute(QU.delete_view, args)

    def get_views(self):
        self.cursor.execute(QU.get_views)

        return self.cursor.fetchall()

    def get_views_by_media(self, *args):
        self.cursor.execute(QU.get_views_by_media, args)

        return self.cursor.fetchall()

    def get_items_by_media(self, *args):
        self.cursor.execute(QU.get_items_by_media, args)

        return self.cursor.fetchall()

    def get_kodi_ids_by_media_folder(self, media_type, library_id):
        """Kodi ids of one media type inside one library."""
        self.cursor.execute(QU.get_kodi_ids_by_media_folder, (media_type, library_id))

        return [row[0] for row in self.cursor.fetchall()]

    def get_item_ids_by_media(self, *args):
        """(jellyfin_id, kodi_id) pairs for a media type."""
        self.cursor.execute(QU.get_item_ids_by_media, args)

        return self.cursor.fetchall()

    def remove_media_by_parent_id(self, *args):
        self.cursor.execute(QU.delete_media_by_parent_id, args)

    def get_version(self):
        self.cursor.execute(QU.get_version)

        return self.cursor.fetchone()

    def add_version(self, *args):
        """
        We only ever want one value here, so erase the existing contents first
        """
        self.cursor.execute(QU.delete_version)
        self.cursor.execute(QU.add_version, args)
