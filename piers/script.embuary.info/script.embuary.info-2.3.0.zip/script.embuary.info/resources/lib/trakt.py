#!/usr/bin/python
# coding: utf-8

########################

import xbmc

from resources.lib.helper import *

########################


def trakt_api(call=None):
    headers = {
        "Content-Type": "application/json",
        "trakt-api-version": "2",
        "trakt-api-key": trakt_api_key(),
    }

    request_url = "https://api.trakt.tv" + call

    for i in range(1, 4):  # loop if heavy server load
        try:
            request = SESSION.get(request_url, timeout=HTTP_TIMEOUT, headers=headers)

            if not request.ok:
                raise Exception(str(request.status_code))

        except Exception as error:
            log("Trakt server error: Code " + str(error), ERROR)
            xbmc.sleep(500)

        else:
            return request.json()
