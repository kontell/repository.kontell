# -*- coding: utf-8 -*-
"""Kodi-database repoint for downloaded items (docs/offline-downloads-plan.md W1.7).

New strict code beside the transplanted writers, in this directory because it
writes MyVideos the way everything here does: explicit columns, cursor in, no
policy. The policy — which item, which directories, when the restore filename
is captured — lives in :mod:`kofin.downloads.repoint`.

The shape is Emby-for-Kodi's, proven mandatory by feasibility V5: the file
row's ``idPath`` moves to a real directory row and ``strFilename`` becomes
the bare basename, so Kodi's save-state resolves back to the row it played —
the one-column shortcut left playback working while watched/resume landed on
a freshly inserted shadow row. ``idFile`` never changes, which is what keeps
bookmarks and play counts attached across repoint and restore (V4).

Episodes mirror their location in ``episode.c18``/``c19`` (FullFilePath and
idPath — the writers populate both on every pass, so repoint and restore
must too). The directory rows above an episode carry the same scraper stamps
the writers put on the show's plugin path row (``tvshows``/``metadata.local``
/``noUpdate``/``useFolderNames``): the info dialog resolves a scraper for the
item's path and silently loses cast, tags, country, director and writer
without them (the CLAUDE.md constraint). For local paths Kodi's parent walk
is string-wise and actually works — the very thing ``plugin://`` paths never
had — so the stamp on the show directory covers every file below it; movies
carry theirs on the title directory, mirroring the writers' per-library row.
"""

from typing import List, Optional, Tuple

import sqlite3

from kofin.core.log import Logger
from kofin.sync.kodidb.kodi import Kodi

LOG = Logger(__name__)

GET_FILE_LOCATION = """
SELECT      idPath, strFilename
FROM        files
WHERE       idFile = ?
"""

# dateAdded deliberately untouched: the repoint owns the location columns and
# nothing else, and the writers' own update_file keeps stamping the rest.
SET_FILE_LOCATION = """
UPDATE      files
SET         idPath = ?, strFilename = ?
WHERE       idFile = ?
"""

SET_EPISODE_LOCATION = """
UPDATE      episode
SET         c18 = ?, c19 = ?
WHERE       idEpisode = ?
"""

PATH_HAS_FILES = """
SELECT      1
FROM        files
WHERE       idPath = ?
LIMIT       1
"""

PATH_HAS_CHILDREN = """
SELECT      1
FROM        path
WHERE       idParentPath = ?
LIMIT       1
"""

DELETE_PATH = """
DELETE FROM path
WHERE       idPath = ?
"""

# The art type the downloaded badge is published under. Namespaced because
# the art table is Kodi's and shared with every scraper and skin helper.
BADGE_ART = "kofin.downloaded"

ADD_BADGE = """
INSERT INTO     art(media_id, media_type, type, url)
VALUES          (?, ?, ?, ?)
"""

EPISODE_PARENTS = """
SELECT      idSeason, idShow
FROM        episode
WHERE       idEpisode = ?
"""

BADGED_SEASONS = """
SELECT      s.idSeason
FROM        seasons s
JOIN        art a ON a.media_id = s.idSeason AND a.media_type = 'season'
WHERE       s.idShow = ?
AND         a.type = ?
"""

DELETE_BADGE = """
DELETE FROM     art
WHERE           media_id = ?
AND             media_type = ?
AND             type = ?
"""


def with_sep(directory: str) -> str:
    """Kodi path rows always carry a trailing separator; POSIX-only, like
    every target this addon runs on."""
    return directory if directory.endswith("/") else directory + "/"


class Downloads(Kodi):
    def __init__(self, cursor: "sqlite3.Cursor") -> None:
        self.cursor = cursor
        Kodi.__init__(self)

    def file_location(self, file_id: int) -> Optional[Tuple[int, str]]:
        self.cursor.execute(GET_FILE_LOCATION, (file_id,))
        row = self.cursor.fetchone()
        if row is None:
            return None
        return int(row[0]), str(row[1] or "")

    def set_file_location(self, file_id: int, path_id: int, filename: str) -> None:
        self.cursor.execute(SET_FILE_LOCATION, (path_id, filename, file_id))

    def set_episode_location(
        self, episode_id: int, full_path: str, path_id: int
    ) -> None:
        self.cursor.execute(SET_EPISODE_LOCATION, (full_path, path_id, episode_id))

    def ensure_movie_paths(self, type_dir: str, title_dir: str) -> int:
        """Get-or-create ``<root>/Movies/`` and the title directory; returns
        the title row id (the file's target). Stamps mirror the writers'
        movie path row (``QU.update_path_movie_obj``): content ``movies``,
        ``metadata.local``, noUpdate, no useFolderNames."""
        type_id = int(self.add_path(with_sep(type_dir)))
        title_id = int(self.add_path(with_sep(title_dir)))
        self.update_path(
            with_sep(title_dir), "movies", "metadata.local", 1, None, title_id
        )
        self.update_path_parent_id(title_id, type_id)
        return title_id

    def ensure_episode_paths(
        self, type_dir: str, show_dir: str, season_dir: Optional[str]
    ) -> int:
        """Get-or-create ``<root>/Shows/``, the show directory and the season
        directory; returns the file's target row id. The show row carries the
        writers' show-row stamps (``QU.update_path_tvshow_obj``), the season
        row stays bare with a parent link — the string-wise parent walk finds
        the show row's scraper from anywhere below it."""
        type_id = int(self.add_path(with_sep(type_dir)))
        show_id = int(self.add_path(with_sep(show_dir)))
        self.update_path(with_sep(show_dir), "tvshows", "metadata.local", 1, 1, show_id)
        self.update_path_parent_id(show_id, type_id)
        if season_dir is None:
            return show_id
        season_id = int(self.add_path(with_sep(season_dir)))
        self.update_path_parent_id(season_id, show_id)
        return season_id

    def set_badge(self, media_id: int, media_type: str, url: str) -> None:
        """Publish the downloaded badge as an ``art`` row.

        Art is how a signal reaches a *native* library list: Kodi loads
        every row for an item (``GetArtForItem`` selects type and url with
        no whitelist) and hands the map to skins as
        ``ListItem.Art(<type>)``, so this shows up in Movies and TV shows,
        not only in kofin's own nodes. The overlay Kodi draws itself is a
        closed seven-value enum set from playcount, so it was never
        available for this.

        The badge deliberately says only "downloaded" — pairing it with
        watched state is the skin's to do, exactly as it already pairs
        ``ListItem.HasVideoVersions`` with everything else. Making the *url*
        depend on playcount would mean rewriting this row on every playback
        and every userdata echo, and a missed rewrite is a badge that lies.
        """
        self.cursor.execute(DELETE_BADGE, (media_id, media_type, BADGE_ART))
        self.cursor.execute(ADD_BADGE, (media_id, media_type, BADGE_ART, url))

    def episode_parents(self, episode_id: int) -> Optional[Tuple[int, int]]:
        """(idSeason, idShow) for an episode, or None when it is gone."""
        self.cursor.execute(EPISODE_PARENTS, (episode_id,))
        row = self.cursor.fetchone()
        if row is None or row[0] is None or row[1] is None:
            return None
        return int(row[0]), int(row[1])

    def badged_seasons_of(self, show_id: int) -> List[int]:
        """Season ids under this show that currently carry a badge."""
        self.cursor.execute(BADGED_SEASONS, (show_id, BADGE_ART))
        return [int(row[0]) for row in self.cursor.fetchall()]

    def clear_badge(self, media_id: int, media_type: str) -> None:
        self.cursor.execute(DELETE_BADGE, (media_id, media_type, BADGE_ART))

    def remove_tag_when_orphaned(
        self, tag: str, media_id: int, media_type: str
    ) -> None:
        """``remove_tag`` plus tag-row cleanup: Kodi's base helper unlinks and
        leaves the tag row for CleanDatabase to sweep someday, which fails the
        L2 zero-trace invariant — a fully removed download must leave the
        database byte-identical, orphan tag rows included."""
        self.remove_tag(tag, media_id, media_type)
        self.cursor.execute(
            "DELETE FROM tag WHERE name = ? COLLATE NOCASE "
            "AND NOT EXISTS (SELECT 1 FROM tag_link WHERE tag_link.tag_id = tag.tag_id)",
            (tag,),
        )

    def prune_paths(self, directories: List[str]) -> int:
        """Delete each directory's row when nothing references it; returns
        how many went. Callers pass bottom-up order (season before show
        before type), so a parent emptied by an earlier deletion in the same
        call is caught by its own turn. A row keeping files — a sibling
        episode still downloaded — or child path rows survives untouched."""
        removed = 0
        for directory in directories:
            path_id = self.get_path(with_sep(directory))
            if path_id is None:
                continue
            self.cursor.execute(PATH_HAS_FILES, (path_id,))
            if self.cursor.fetchone() is not None:
                continue
            self.cursor.execute(PATH_HAS_CHILDREN, (path_id,))
            if self.cursor.fetchone() is not None:
                continue
            self.cursor.execute(DELETE_PATH, (path_id,))
            removed += 1
        return removed


# LEFT JOIN: a song whose path row is gone still has a location to report
# (the id and the filename), and "" for the string is what tells the repoint
# there is nothing to capture.
GET_SONG_LOCATION = """
SELECT      song.idPath, song.strFileName, path.strPath
FROM        song
LEFT JOIN   path ON path.idPath = song.idPath
WHERE       song.idSong = ?
"""

SET_SONG_LOCATION = """
UPDATE      song
SET         idPath = ?, strFileName = ?
WHERE       idSong = ?
"""

PATH_HAS_SONGS = """
SELECT      1
FROM        song
WHERE       idPath = ?
LIMIT       1
"""


class MusicDownloads(Kodi):
    """The MyMusic half of the repoint (plan W3.2).

    Far smaller than the video one on purpose: MyMusic's ``path`` table is
    bare (idPath, strPath — no scraper stamps, no parent links), Kodi
    rebuilds a song's playable path as ``AddFileToFolder(path.strPath,
    song.strFileName)`` with no full-URL arm, and only the album directory
    ever needs a row — nothing references the artist level. The base
    ``add_path``/``get_path`` SQL is two-column and serves both databases.
    """

    def __init__(self, cursor: "sqlite3.Cursor") -> None:
        self.cursor = cursor
        Kodi.__init__(self)

    def song_location(self, song_id: int) -> Optional[Tuple[int, str, str]]:
        """(idPath, strFileName, strPath) — strPath "" when the row is gone."""
        self.cursor.execute(GET_SONG_LOCATION, (song_id,))
        row = self.cursor.fetchone()
        if row is None:
            return None
        return int(row[0]), str(row[1] or ""), str(row[2] or "")

    def set_song_location(self, song_id: int, path_id: int, filename: str) -> None:
        self.cursor.execute(SET_SONG_LOCATION, (path_id, filename, song_id))

    def ensure_song_path(self, directory: str) -> int:
        """Get-or-create the album directory's row; the file's target."""
        return int(self.add_path(with_sep(directory)))

    def prune_song_path(self, directory: str) -> bool:
        """Drop the directory row when no song references it any more."""
        path_id = self.get_path(with_sep(directory))
        if path_id is None:
            return False
        self.cursor.execute(PATH_HAS_SONGS, (path_id,))
        if self.cursor.fetchone() is not None:
            return False
        self.cursor.execute(DELETE_PATH, (path_id,))
        return True
