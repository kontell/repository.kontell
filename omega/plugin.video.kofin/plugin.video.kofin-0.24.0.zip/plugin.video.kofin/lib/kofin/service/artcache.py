"""Pre-seed Kodi's texture cache with the cast thumbnails the info dialog
is about to ask for.

The info dialog renders an actor tile by handing Kodi the art URL the sync
wrote into MyVideos; Kodi then fetches, decodes, rescales and caches it on
first sight. Measured on this repo's test box: ~110 ms per actor cold against
~1 ms warm, on a library holding 19,661 actor thumb URLs of which 102 were
cached — so every first open of a film's info dialog paid its whole cast, and
paid it again for the next film.

Nothing about the URLs is wrong (they are already capped at 400 px by
``sync/fields.get_people_artwork``); the cost is that the work happens while
someone is looking at an empty tile. So this module does that work earlier, on
an idle box, through the same contract ``service/chapters.py`` uses for
chapter thumbs: the file under ``Thumbnails/`` at Kodi's CRC-named path, plus
a ``texture`` row whose empty ``imagehash``/``lasthashcheck`` marks it trusted
and a ``sizes`` row with ``size=1``. The encoder was re-verified against real
rows Kodi itself wrote for actor art before this module existed
(``test_artcache.py`` carries those vectors).

Two things it deliberately does not do. It never rewrites a URL: a changed URL
shape would only take effect for items the sync happens to touch again, so the
cache would agree with the library for some rows and not others. And it never
reverts: unlike a chapter thumb, whose key embeds a per-play session id, an
actor tile stays valid for as long as the art URL does, and Kodi's own texture
cleanup owns the eviction. "Clean databases" removes them with the rest of the
cached server art (``sync/clean.purge_server_art``).
"""

import os
import threading
from typing import Any, Dict, List, Optional, Set, Tuple

import xbmc
import xbmcvfs

from kofin.core import settings
from kofin.core.http import Http, HttpError
from kofin.core.imagecache import THUMBNAILS, extension_for, store_image
from kofin.core.log import Logger
from kofin.sync import schema
from kofin.sync.db import Database
from kofin.sync.kodidb.texture import TextureCache, cached_rel_path

LOG = Logger(__name__)

JsonDict = Dict[str, Any]

# THUMBNAILS, the parser and the store step live in core/imagecache (P1.10).

# The setting that turns the idle trickle on. Off by default: it is disk the
# user has not agreed to spend (see the help string's estimate).
SETTING = "precacheActorArt"

# Seconds of Kodi idle before a batch runs. Long enough that it never competes
# with someone browsing, short enough to make progress during an evening.
IDLE_SECONDS = 60

# Images per wake. Bounded so a batch can always finish promptly when
# playback starts or the service shuts down, and so the texture database is
# only held for one batch's worth of inserts at a time.
BATCH = 25

# Seconds between wakes while there is work left.
TICK_SECONDS = 15

# Short and un-retried: a cast tile that does not arrive promptly is not worth
# holding an idle-time worker for, and the next batch will pick it up again.
TIMEOUT = (3.05, 10.0)

# Actor thumbs only. Posters and fanart are already cached as a side effect of
# browsing the library — they are on screen the moment a list is drawn — while
# cast art is the one kind nothing renders until a dialog opens.
_PENDING_QUERY = """
SELECT      DISTINCT url
FROM        art
WHERE       media_type = 'actor' AND type = 'thumb'
            AND url LIKE 'http%'
"""


def pending_urls(limit: int) -> List[str]:
    """The next ``limit`` actor thumb URLs the texture cache has no row for.

    Both sides are read whole and differenced here rather than paged in SQL:
    they live in different database files, so there is no join to push down,
    and a LIMIT on the candidate side alone does not advance — the first page
    of art rows is the same page next time, so once it is cached the query
    answers "nothing pending" with the other 19,000 still missing. (Measured
    exactly that way on the first live run: 186 seeded, then a claim of
    completion.) A whole-column read of both tables is a few milliseconds
    against a batch of network fetches, and it makes progress monotonic.
    """
    with Database("video") as video_db:
        video_db.cursor.execute(_PENDING_QUERY)
        candidates = [row[0] for row in video_db.cursor.fetchall() if row[0]]
    if not candidates:
        return []

    with Database("texture") as texture_db:
        texture_db.cursor.execute("SELECT url FROM texture")
        cached = {row[0] for row in texture_db.cursor.fetchall()}

    pending: List[str] = []
    for url in candidates:
        if url in cached:
            continue
        pending.append(url)
        if len(pending) >= limit:
            break
    return pending


class ActorArtCache:
    """The idle-time seeder, and the settings button's worker.

    One instance per service generation; ``start`` and ``stop`` are the whole
    interface. Nothing here raises into its caller.
    """

    def __init__(self, thumbs_dir: Optional[str] = None) -> None:
        self._thumbs_dir = thumbs_dir or xbmcvfs.translatePath(THUMBNAILS)
        self._http = Http(settings.get_bool("sslVerify"))
        self._halt = threading.Event()
        self._thread: Optional[threading.Thread] = None
        # The idle trickle and the settings button are the same work through
        # two doors, and each computes its own list — run them at once (seen
        # live) and both fetch the same images. One instance, one lock, so
        # whichever starts second waits and then reads a list the first has
        # already shortened.
        self._working = threading.Lock()
        # URLs the server will not serve. A library carries art rows whose
        # image the server has since lost (404) or cannot render (500) —
        # measured on the test library — and nothing ever caches them, so the
        # work list hands back the same dead URLs on every pass and a batch
        # spends itself on them. Skipped for this service generation only: a
        # restart re-tries, which is the right cadence for a server-side fix.
        self._unservable: Set[str] = set()

    # -- lifecycle -------------------------------------------------------------

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._halt.clear()
        self._thread = threading.Thread(target=self._run, name="kofin-artcache")
        self._thread.daemon = True
        self._thread.start()

    def stop(self, timeout: float = 10.0) -> None:
        """Halt and join. Bounded: a batch is BATCH short fetches, and the
        worker checks the flag between every one."""
        self._halt.set()
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=timeout)
            if thread.is_alive():  # pragma: no cover - watchdog logging only
                LOG.warning("actor art seeder did not stop within its deadline")
        self._http.close()

    # -- the idle trickle --------------------------------------------------------

    def _run(self) -> None:
        monitor = xbmc.Monitor()
        # Nothing to do until the user asks for it; the flag is read per wake
        # so turning it on takes effect without a service restart.
        while not monitor.abortRequested() and not self._halt.is_set():
            if monitor.waitForAbort(TICK_SECONDS):
                return
            if self._halt.is_set() or not settings.get_bool(SETTING):
                continue
            if not self._idle():
                continue
            try:
                seeded = self.seed_batch()
            except schema.SchemaError as error:
                LOG.debug("actor art seeding unavailable: %s", error)
                return
            except Exception:
                LOG.exception("actor art seeding failed")
                return
            if seeded:
                LOG.debug("seeded %d actor thumb(s)", seeded)

    def _playing(self) -> bool:
        """Whether something is playing.

        Both entry points check it: the seeder pulls images from the same
        server the stream is coming off, and neither the trickle nor the
        button is worth a stutter.
        """
        return bool(xbmc.Player().isPlaying())

    def _idle(self) -> bool:
        """Whether now is a fair time to spend disk and bandwidth.

        Never during playback, and only once the box has been left alone.
        The button does *not* use this: someone who just pressed it has by
        definition not left the box alone, and gating on idle time would mean
        it never ran.
        """
        if self._playing():
            return False
        return xbmc.getGlobalIdleTime() >= IDLE_SECONDS

    # -- the work --------------------------------------------------------------

    def seed_batch(self, limit: int = BATCH) -> int:
        """Seed up to ``limit`` uncached actor thumbs; returns how many landed.

        The file is written before the row is inserted, and the rows for the
        whole batch go in one transaction at the end: a row is a promise that
        the file is there, so it must never be the earlier of the two.
        """
        with self._working:
            return self._seed_batch(limit)

    def _seed_batch(self, limit: int) -> int:
        urls = [
            url
            for url in pending_urls(limit + len(self._unservable))
            if url not in self._unservable
        ][:limit]
        if not urls:
            return 0

        published: List[Tuple[str, str, int, int]] = []
        for url in urls:
            if self._halt.is_set():
                break
            data = self._download(url)
            if not data:
                continue
            relative = cached_rel_path(url, extension_for(data))
            destination = os.path.join(self._thumbs_dir, relative)
            try:
                width, height = store_image(data, destination)
            except OSError as error:
                LOG.debug("could not write %s: %s", destination, error)
                continue
            published.append((url, relative, width, height))

        if not published:
            return 0
        with Database("texture") as texture_db:
            cache = TextureCache(texture_db.cursor)
            for url, relative, width, height in published:
                cache.add(url, relative, width, height)
        return len(published)

    def seed_all(self) -> int:
        """Seed everything outstanding, for the settings button.

        Runs to exhaustion rather than one batch — the user asked for it —
        and reports the total. Shares the instance lock with the trickle, so
        the two never fetch the same image twice, and honours the same halt
        flag, so a service shutdown ends it promptly.

        Playback ends the run (see the check below). It is tested between
        batches rather than between images: a batch is 25 short fetches,
        about a second at the rate this runs, so the overlap is not worth
        checking the player 25 times to avoid.
        """
        total = 0
        while not self._halt.is_set():
            if self._playing():
                # "Now" means now, not instead of the film. Stopping rather
                # than parking the thread for two hours: the run is resumable
                # by construction (a seeded image is skipped next time), so
                # pressing the button again — or leaving the idle trickle on —
                # picks up exactly where this left off.
                LOG.info(
                    "actor art pre-cache yielding to playback after %d image(s)",
                    total,
                )
                break
            seeded = self.seed_batch()
            if not seeded:
                break
            total += seeded
        LOG.info("actor art pre-cache: %d image(s) seeded", total)
        return total

    def _download(self, url: str) -> bytes:
        """The image bytes, or b'' for anything that went wrong.

        Anonymous, like every other art fetch: these URLs carry their own
        image tag and Jellyfin serves them without a token.

        A 4xx/5xx is the server saying it will not serve this image at all
        (a stale tag, a lost file); those go on the skip list so the next
        batch spends itself on images that can actually land. A transport
        failure is not remembered — that is the network, and it will pass.
        """
        try:
            response = self._http.request("GET", url, timeout=TIMEOUT, retries=0)
        except HttpError as error:
            LOG.debug("actor art unavailable (%s): %s", url[:80], error)
            self._unservable.add(url)
            return b""
        except Exception as error:
            LOG.debug("actor art fetch failed (%s): %s", url[:80], error)
            return b""
        content: bytes = response.content or b""
        return content
