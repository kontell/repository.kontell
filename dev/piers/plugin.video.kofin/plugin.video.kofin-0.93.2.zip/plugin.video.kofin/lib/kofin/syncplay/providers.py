"""The provider seam: how the engine starts content and maps local plays.

G1 of ``docs/syncplay-generic-backend-plan.md``. The engine coordinates the
*global* Kodi player; what a queue item id means — how to start it at a
position, and how a Kodi library id maps back to one — is the owning
provider's business. Today there is exactly one provider,
Jellyfin-through-kofin, and this seam exists so there can be another without
the engine changing shape (``docs/syncplay-generic-backend-feasibility.md``
§5).

Kept in the ``ports.py`` discipline: the engine types against the Protocol,
the registry is the only dispatch, and the Jellyfin implementation is the one
place the engine's start path may reach kofin's plugin URL builder and sync
database.
"""

from typing import Dict, Optional, Protocol, TypedDict
from urllib.parse import quote

from kofin import buildconfig
from kofin.core.urls import plugin_url
from kofin.syncplay.ports import JsonDict, SyncPlayApi

#################################################################################################

JELLYFIN = "jellyfin"

# Jellyfin item types whose length is not fixed, so no runtime is claimed for
# them: channels and programmes, and ``Recording`` — a recording still being
# written is already longer than the length it was probed at.
LIVE_TYPES = frozenset(
    {"TvChannel", "LiveTvChannel", "Program", "LiveTvProgram", "Recording"}
)


class _PlayTargetRequired(TypedDict):
    url: str
    audio: bool


class PlayTarget(_PlayTargetRequired, total=False):
    """What the playback controller needs to start a queue item: the URL to
    hand Kodi, and which playlist it belongs on.

    ``runtime_ticks`` is the item's length where its provider can vouch for
    one, so the engine can decline a start aimed at or past the end. A
    provider that cannot — live content, a template or delegated provider —
    leaves it out, and nothing is checked."""

    runtime_ticks: int


class Provider(Protocol):
    """What the engine needs from a content provider (plan G1.1)."""

    def play_target(self, key: str, start_ticks: int) -> PlayTarget: ...

    def resolve_kodi_id(self, kodi_id: int, media: str) -> Optional[str]: ...


#################################################################################################


class JellyfinProvider:
    """Jellyfin-through-kofin: the reference provider.

    ``api`` mirrors the manager's Optional client: a manager built without
    one answers every start with a failed lookup, exactly as the getattr
    dispatch answered None before the seam existed.
    """

    def __init__(self, api: Optional[SyncPlayApi]):
        self.api = api

    def play_target(self, key: str, start_ticks: int) -> PlayTarget:
        # Direct on the client, not via the manager's _api wrapper: a 403
        # here is a library permission problem, not lost group membership.
        if self.api is None:
            raise LookupError("no API client")

        item = self.api.item(key)

        if not item:
            raise LookupError("item lookup failed")

        params = {"mode": "play", "id": str(key)}

        # Always sent, and never negative. A group start names the position
        # even when that position is zero, so a falsy 0 must not be dropped —
        # omitting it lets the play route fall back to the member's own resume
        # point, which starts it minutes away from the group. And the estimate
        # can land just below zero (extrapolation across a clock offset), which
        # was measured reaching the route as startticks=-240000.
        params["startticks"] = str(max(0, int(start_ticks or 0)))

        target: PlayTarget = {
            "url": plugin_url(params),
            "audio": item.get("Type") == "Audio",
        }
        runtime_ticks = self._runtime_ticks(item)

        if runtime_ticks:
            target["runtime_ticks"] = runtime_ticks

        return target

    @staticmethod
    def _runtime_ticks(item: JsonDict) -> int:
        """The longest this item can run, or 0 when that is not known.

        The longest of its versions, not the item's own figure: that one
        describes the primary version, and a member may be on a longer cut.
        Nothing for the live kinds — a recording still being written is
        already longer than whatever length it was probed at.
        """
        if item.get("Type") in LIVE_TYPES:
            return 0

        sources = item.get("MediaSources") or []

        return max(
            [int(item.get("RunTimeTicks") or 0)]
            + [int(source.get("RunTimeTicks") or 0) for source in sources]
        )

    def resolve_kodi_id(self, kodi_id: int, media: str) -> Optional[str]:
        if buildconfig.BACKEND != "sql":
            # The API build keeps no table of Kodi ids: a native row is ours
            # when its unique id and resolver URL say so, which is the lookup
            # the library claim and the userdata watcher already make.
            # sync.private.get_item answers None for every row on this build,
            # so every library play in a group read as a foreign item and was
            # released as unmanaged ~100 ms after it started. A lookup that
            # fails raises: the caller leaves that play to its claim rather
            # than calling it foreign.
            from kofin.sync.backends.api.identity import mapped_item

            item_id = mapped_item(kodi_id, media)
            return str(item_id) if item_id else None

        from kofin.sync import private as database  # deferred: pulls in the DB stack

        mapped = database.get_item(kodi_id, media)
        return mapped[0] if mapped else None


#################################################################################################


class TemplateProvider:
    """A provider registered over the public bus (plan G2.4): start-only.

    The template names ``{key}`` and optionally ``{position_s}`` (whole
    seconds). Substitution is by token replace, never str.format — the
    template is foreign text and must not be able to name anything else.
    ``resolve_kodi_id`` answers None: a foreign provider has no claim on
    the Kodi library; its plays are identified by the claims it publishes.
    """

    def __init__(self, template: str, audio: bool = False):
        self.template = template
        self.audio = audio

    def play_target(self, key: str, start_ticks: int) -> PlayTarget:
        seconds = max(0, int(start_ticks or 0)) // 10000000
        url = self.template.replace("{key}", quote(key, safe="")).replace(
            "{position_s}", str(seconds)
        )
        return {"url": url, "audio": self.audio}

    def resolve_kodi_id(self, kodi_id: int, media: str) -> Optional[str]:
        return None


class DelegatedProvider:
    """A provider whose starts the engine cannot make (the provider
    contract's delegated start): its content is tuned, not fetched, so
    there is no URL to build — the engine broadcasts SyncSession.Start
    and the provider's own service executes it."""

    delegated = True

    def __init__(self, audio: bool = False):
        self.audio = audio

    def play_target(self, key: str, start_ticks: int) -> PlayTarget:
        raise LookupError("delegated provider has no play target")

    def resolve_kodi_id(self, kodi_id: int, media: str) -> Optional[str]:
        return None


class ProviderRegistry:
    """The engine's one dispatch from a content key to its provider.

    G1 knows a single provider; G2's ``SyncProvider.Register`` intake is what
    grows this beyond ``jellyfin``, and the queue side stays keyed by the
    default until G3's descriptors name a provider per entry.
    """

    def __init__(self) -> None:
        self._providers: Dict[str, Provider] = {}

    def register(self, name: str, provider: Provider) -> None:
        self._providers[name] = provider

    def get(self, name: str = JELLYFIN) -> Provider:
        return self._providers[name]

    def is_delegated(self, name: str) -> bool:
        """Whether the named provider takes delegated starts. False for an
        unregistered name — the ordinary start path then fails the load
        with the same lookup error it always has."""
        provider = self._providers.get(name)
        return bool(getattr(provider, "delegated", False))

    def play_target(
        self, key: str, start_ticks: int, provider: str = JELLYFIN
    ) -> PlayTarget:
        return self.get(provider).play_target(key, start_ticks)

    def resolve_kodi_id(self, kodi_id: int, media: str) -> Optional[str]:
        # The default provider owns the Kodi library today; a second library
        # owner joins this dispatch when one exists.
        return self.get(JELLYFIN).resolve_kodi_id(kodi_id, media)


def jellyfin_registry(api: Optional[SyncPlayApi]) -> ProviderRegistry:
    """The registry every kofin service starts with."""
    registry = ProviderRegistry()
    registry.register(JELLYFIN, JellyfinProvider(api))
    return registry
