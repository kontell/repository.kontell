"""Read public Kodi capabilities inside the addon; no HTTP server required."""

import json
from pathlib import Path

import xbmcaddon
import xbmcgui

from kofin.core import kodirpc
from . import companion
from .contract import check


def inspect(allow_dirty=False):
    contract = json.loads(Path(__file__).with_name("requirements.json").read_text())
    schema = kodirpc.call(
        "JSONRPC.Introspect", {"getdescriptions": False, "getmetadata": True}
    )
    application = kodirpc.call(
        "Application.GetProperties", {"properties": ["version", "name"]}
    )
    capture = {
        "application": application if isinstance(application, dict) else {},
        "methods": schema.get("methods", {}) if isinstance(schema, dict) else {},
        "system_addons": {},
    }
    for name in contract["system_addons"]:
        try:
            capture["system_addons"][name] = xbmcaddon.Addon(name).getAddonInfo(
                "version"
            )
        except Exception:
            capture["system_addons"][name] = "0"
    item = xbmcgui.ListItem(offscreen=True)
    for key, tag in (
        ("python_video_methods", item.getVideoInfoTag()),
        ("python_music_methods", item.getMusicInfoTag()),
    ):
        capture[key] = {name: hasattr(tag, name) for name in contract["python"][key]}
    report = check(capture, contract, allow_dirty=allow_dirty)
    report.update(
        {
            "backend": "api",
            "native_sync_enabled": report["interfaces_passed"],
            "native_sync_scope": (
                [
                    "Movie",
                    "Series",
                    "Season",
                    "Episode",
                    "MusicVideo",
                    "BoxSet",
                    "Audio",
                    "MusicAlbum",
                    "MusicArtist",
                ]
                if report["interfaces_passed"]
                else []
            ),
            "application": capture["application"],
            # The companion add-on closes what public interfaces cannot
            # (companion.py); its absence is a feature reduced, never a
            # fault, and its last status says what it serves and refuses.
            "companion": companion.status_block(),
        }
    )
    return report
