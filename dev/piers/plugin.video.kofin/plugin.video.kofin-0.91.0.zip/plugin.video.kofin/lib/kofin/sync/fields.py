# -*- coding: utf-8 -*-
"""Item-shaping helpers the writers depend on (fork ``helper/api.py`` plus
the checksum/skip logic from ``objects/utils.py``).

Adaptations (plan §3): native-mode path replacement dropped (plugin paths
only); artwork-quality settings read kofin's Sync tab ids (``compressArt``,
``maxArtResolution`` where 0 means original size);
``find_library`` resolves through the kofin Api and sync.json whitelist.
"""

from typing import List

from kofin.sync.model import (
    Metadata,
    PROVIDER_PRIORITY as PROVIDER_PRIORITY,
    streams_and_runtime as streams_and_runtime,
    ratings as ratings,
    unique_ids as unique_ids,
)

from kofin.sync.policy import plan_update, reference_checksum

from kofin.core import settings
from kofin.core.http import HttpError
from kofin.core.log import Logger

LOG = Logger(__name__)


class API(Metadata):
    def __init__(self, item, server=None):
        """Get item information in special cases.
        server is the server address, provide if your functions requires it.
        """
        super().__init__(item)
        self.server = server

    @classmethod
    def adjust_resume(cls, resume_seconds):

        resume: float = 0
        if resume_seconds:
            # The jumpback rule itself lives in core.settings so the bookmark
            # written here, the resume point a listing advertises and the
            # position playback starts at cannot drift apart.
            resume = settings.adjusted_resume(round(float(resume_seconds), 6))

        return resume

    def get_user_artwork(self, user_id):
        """Get jellyfin user profile picture."""
        return "%s/UserImage?userId=%s&Format=original" % (self.server, user_id)

    def get_people_artwork(self, people):
        """Get people (actor, director, etc) artwork."""
        for person in people:

            if "PrimaryImageTag" in person:

                query = "&MaxWidth=400&MaxHeight=400&Index=0"
                person["imageurl"] = self.get_artwork(
                    person["Id"], "Primary", person["PrimaryImageTag"], query
                )
            else:
                person["imageurl"] = None

        return people

    def get_all_artwork(self, obj, parent_info=False):
        """Get all artwork possible. If parent_info is True,
        it will fill missing artwork with parent artwork.

        obj is from objects.Objects().map(item, 'Artwork')
        """
        query = ""
        all_artwork = {
            "Primary": "",
            "BoxRear": "",
            "Art": "",
            "Banner": "",
            "Logo": "",
            "Thumb": "",
            "Disc": "",
            "Backdrop": [],
        }

        if settings.get_bool("compressArt"):
            query = "&Quality=90"

        maxheight = settings.get_int("maxArtResolution")
        if maxheight:
            query += "&MaxHeight=%d" % maxheight

        all_artwork["Backdrop"] = self.get_backdrops(
            obj["Id"], obj["BackdropTags"] or [], query
        )

        for artwork in obj["Tags"] or []:
            all_artwork[artwork] = self.get_artwork(
                obj["Id"], artwork, obj["Tags"][artwork], query
            )

        if parent_info:

            if not all_artwork["Backdrop"] and obj["ParentBackdropId"]:
                all_artwork["Backdrop"] = self.get_backdrops(
                    obj["ParentBackdropId"], obj["ParentBackdropTags"], query
                )

            for art in ("Logo", "Art", "Thumb"):
                if not all_artwork[art] and obj["Parent%sId" % art]:
                    all_artwork[art] = self.get_artwork(
                        obj["Parent%sId" % art], art, obj["Parent%sTag" % art], query
                    )

            if obj.get("SeriesTag"):
                all_artwork["Series.Primary"] = self.get_artwork(
                    obj["SeriesId"], "Primary", obj["SeriesTag"], query
                )

                if not all_artwork["Primary"]:
                    all_artwork["Primary"] = all_artwork["Series.Primary"]

            elif not all_artwork["Primary"] and obj.get("AlbumId"):
                all_artwork["Primary"] = self.get_artwork(
                    obj["AlbumId"], "Primary", obj["AlbumTag"], query
                )

        return all_artwork

    def get_backdrops(self, item_id, tags, query=None):
        """Get backdrops based of "BackdropImageTags" in the jellyfin object."""
        backdrops: List[str] = []

        if item_id is None:
            return backdrops

        for index, tag in enumerate(tags):

            artwork = "%s/Items/%s/Images/Backdrop/%s?Format=original&Tag=%s%s" % (
                self.server,
                item_id,
                index,
                tag,
                (query or ""),
            )
            backdrops.append(artwork)

        return backdrops

    def get_artwork(self, item_id, image, tag=None, query=None):
        """Get any type of artwork: Primary, Art, Banner, Logo, Thumb, Disc"""
        if item_id is None:
            return ""

        url = "%s/Items/%s/Images/%s/0?Format=original" % (self.server, item_id, image)

        if tag is not None:
            url += "&Tag=%s" % tag

        if query is not None:
            url += query or ""

        return url


def youtube_video_id(url):
    """The video id in any of the YouTube URL shapes Jellyfin stores in
    ``RemoteTrailers`` verbatim — ``watch?v=``, ``youtu.be/``, ``/shorts/``,
    ``/embed/`` — or None for anything else.

    The writers used to take ``rsplit("=", 1)[1]``, which raised IndexError
    on every shape but ``watch?v=`` and logged a full traceback per film for
    an ordinary link (audit R3). None keeps the "no trailer" outcome without
    the noise.
    """
    if not url or not isinstance(url, str):
        return None
    text = url.strip()
    query_start = text.find("?")
    if query_start >= 0:
        for pair in text[query_start + 1 :].split("&"):
            if pair.startswith("v=") and len(pair) > 2:
                return pair[2:].split("#", 1)[0]
    path = text.split("?", 1)[0].split("#", 1)[0]
    for marker in ("youtu.be/", "/shorts/", "/embed/"):
        if marker in path:
            candidate = path.split(marker, 1)[1].strip("/").split("/", 1)[0]
            if candidate:
                return candidate
    return None


def gone_on_fetch(error):
    """Whether a child fetch's failure means the item itself is gone.

    A writer that asks the server about the item it is writing -- a movie's
    trailers or special features, a show's trailers -- gets a 404 when the
    item was deleted between the page it came in on and the write. The fork
    swallowed that with every other fetch error and wrote the row anyway;
    kofin's writers re-raise on this one answer, and the walk's gone-skip
    (``full_sync.apply_or_skip``) or the worker's unapplied flag takes it
    from there. Only a 404 says gone: the status a child fetch answers with
    is the endpoint's, and anything else is a fetch problem the writer still
    absorbs as before.
    """
    return isinstance(error, HttpError) and error.status == 404


# The order that decides which provider Kodi's pointer names, and the order
# the rows are written in. Shared with the NFO exporter, so a downloaded
# item's .nfo defaults the same id the library row points at
# (downloads/export.uniqueid_lines).


def sync_checksum(item, direct_path):
    """Reference checksum stored with a fully synced item.

    The server Etag hashes DateLastSaved, so it changes on every metadata,
    image or file change but not on userdata changes. The path mode is baked
    in so toggling direct paths can never be masked by a matching Etag.
    """
    etag = item.get("Etag") if isinstance(item, dict) else None

    return reference_checksum(etag, direct_path)


def etag_match(item, e_item, direct_path):
    """True when the synced reference is already up to date with the item."""
    expected = sync_checksum(item, direct_path)

    return expected is not None and getattr(e_item, "checksum", None) == expected


def check_unchanged(
    writer, obj, item, e_item, update, apply_userdata=True, force=False
):
    """Stamp the reference checksum on obj and report whether the full write
    cascade can be skipped.

    On a match only userdata can differ, so it is applied from the payload in
    hand (unless the type has no userdata handler) and the item is recorded
    as processed.

    An incremental sync tags the item with whether it actually carried a
    userdata change; when it did not, the userdata write is skipped. Items
    without the tag (full sync) apply userdata as before.

    ``force`` rewrites through a match: the caller knows the rows are wrong
    for a reason the Etag cannot see -- a track whose artist entity was
    created after the track was saved (Music.relink_content, issue #188).
    """
    # Unconditional: the mapping default was json.dumps(item["UserData"]) — a
    # value no comparator can ever match, moving on every playback, so an
    # Etag-less item rewrote itself on every walk and dragged the widget
    # reference digest with it (healing-loops-plan F4). NULL has defined
    # semantics instead: re-verify every walk, visibly (kofindb warns).
    decision = plan_update(
        item,
        getattr(e_item, "checksum", None),
        exists=bool(update),
        direct_path=writer.direct_path,
        force=force,
        allow_userdata=apply_userdata,
    )
    obj["Checksum"] = decision.checksum

    if not decision.skip_metadata:
        return False

    LOG.debug(
        "Skipping unchanged %s %s: %s", item.get("Type"), obj["Id"], obj.get("Title")
    )

    if decision.apply_userdata:
        writer.userdata(item)

    writer.item_ids.append(obj["Id"])

    return True


# Art media types the artwork-only path can stamp (Kodi video art tables).
ARTWORK_MEDIA = ("movie", "tvshow", "season", "episode", "musicvideo")


def artwork_only(writer, item, e_item):
    """Apply an image-only update: artwork rows + reference checksum, no
    write cascade (phase 5, plan §2).

    Writer-adjacent, not a writer change — it reuses the exact seam every
    writer already exercises (``self.artwork.add(...)`` on the mapped
    Artwork object) plus the update_reference checksum stamp. Returns False
    on anything unexpected (unknown reference, missing ids); the caller
    falls the item back to the full update path.
    """
    if e_item is None:
        LOG.debug("artwork-only: %s unknown locally", item.get("Id"))
        return False

    try:
        kodi_id = e_item[0]
        media = e_item[4]

        if not kodi_id or media not in ARTWORK_MEDIA:
            return False

        item_api = API(item, writer.server.server)
        artwork = item_api.get_all_artwork(writer.objects.map(item, "Artwork"))
        writer.artwork.add(artwork, kodi_id, media)

        checksum = sync_checksum(item, writer.direct_path)
        if checksum:
            writer.jellyfin_db.update_reference(checksum, item["Id"])

        LOG.debug("Artwork-only update %s %s", media, item["Id"])
        return True
    except Exception as error:
        LOG.exception(error)
        return False


def find_library(server, item, cache=None):
    """The whitelisted ancestor view of an item that arrived without library
    context (realtime events), or {} when it belongs to no synced library.

    ``server`` is the kofin Api.

    ``cache`` is an optional dict owned by the caller (one per writer
    instance). The ``/Items/{id}/Ancestors`` walk this needs is a round trip
    the server is slow to answer — ~450ms against a real library — and it was
    being charged once per item, which is what capped a queued backlog at
    roughly one item a second. The answer depends only on the whitelist and
    the item's parent, so resolving it once per parent is exact: siblings
    share a parent, hence a library. Songs key on their album and albums on
    their artist, so a 20k-track backlog pays per album rather than per track.
    Misses memoize on the same terms as hits, so an item in a library the user
    does not sync costs one round trip per parent rather than one per item.
    """
    from kofin.sync.private import get_sync

    sync = get_sync()
    whitelist = [x.replace("Mixed:", "") for x in sync["Whitelist"]]
    # The whitelist is part of the key: it can change mid-drain from the
    # settings dialog, and a memo that outlived it would keep writing items
    # into a library the user just de-selected.
    key = (frozenset(whitelist), item.get("ParentId"))
    cacheable = cache is not None and key[1]

    if cacheable and key in cache:
        return cache[key]

    ancestors = server.ancestors(item["Id"])
    for ancestor in ancestors:
        if ancestor["Id"] in whitelist:
            if cacheable:
                cache[key] = ancestor

            return ancestor

    artist = item.get("Type") == "MusicArtist"

    if artist:
        # Artists are server-global entities, not children of a library:
        # a folder-less artist (metadata-only, every artist whose tag came
        # from files inside album folders) answers /Ancestors with [], and
        # even a folder-backed one only names the folder it happens to live
        # in. So a realtime "artist added" could never resolve a library
        # here and the artist was silently dropped — which is how an artist
        # deleted and re-created by the server (it still had a track on a
        # compilation) stayed missing until a repair. The artist's albums
        # and songs do have ancestors; resolve through one of them. Not
        # memoized: the cache key is the parent folder, and an artist's
        # content decides this answer, not its folder siblings.
        library = _artist_library(server, item["Id"], whitelist)
        if library:
            LOG.info(
                "Artist %s resolved to library %s through its content",
                item["Id"],
                library["Id"],
            )
            return library

    # Memoize the miss too. It answers the same question a hit does -- which
    # library do this parent's children belong to -- and "none of ours" is as
    # true for every sibling as "the Shows library" would have been. Caching
    # only hits meant an item in a library the user does not sync paid a round
    # trip on every drain, forever: 12,404 of them in ~17 minutes on a live
    # box, for a library that was never going to be written. Artists are
    # exempt for the same reason their hits are -- their content decides this,
    # not their folder siblings.
    if cacheable and not artist:
        cache[key] = {}

    # Expected, not faulty: an item outside the whitelist is exactly what this
    # is for. An empty whitelist -- the pathological case, where *everything*
    # lands here -- is caught upstream by db.get_sync raising SyncStateCorrupt.
    LOG.warning("No ancestor found, not syncing item with ID: %s", item["Id"])
    return {}


def _artist_library(server, artist_id, whitelist):
    """The whitelisted ancestor view of one of the artist's albums or songs,
    or {} for an artist with no content in any whitelisted library."""
    listing = server.items(
        {
            "ArtistIds": artist_id,
            "Recursive": True,
            "IncludeItemTypes": "MusicAlbum,Audio",
            "Limit": 1,
            "EnableTotalRecordCount": False,
        }
    )

    for child in listing.get("Items") or []:
        for ancestor in server.ancestors(child["Id"]):
            if ancestor["Id"] in whitelist:
                return ancestor

    return {}
