"""What every request kind implements."""

from typing import Any, Dict, List, Tuple

from companion.contract import Request
from companion.ledger import Entry


class Refused(Exception):
    """The request cannot be served as asked; Kofin reads the reason."""

    # An answer, not a fault: the database block it leaves does not log it
    # as an error (db.Database.__exit__).
    expected = True

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


class Retry(Exception):
    """Not now (a lock, a scan): tried again at the next wake."""

    expected = True

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


class Context:
    """What a handler is given beside the request: the document's identity
    and a place to log. Handlers open databases themselves (``db.Database``),
    so a test can point a kind at a fixture through ``db.set_path_override``."""

    def __init__(self, namespace: str, device: str, gate: Dict[str, Dict[str, Any]]):
        self.namespace = namespace
        self.device = device
        self.gate = gate

    def version(self, kind: str) -> int:
        entry = self.gate.get(kind) or {}
        return int(entry.get("version") or 0)


class Handler:
    kind: str = ""
    # The settings toggle that gates the family this kind belongs to.
    family: str = ""
    # The database kinds the handler writes; each must pass the gate.
    needs: Tuple[str, ...] = ()
    # A viewer is waiting on it: served before every other request of a run.
    # Order and nothing else: whether a request waits for a library scan is
    # read off ``needs`` (``reconciler.SCANNED``), never off this flag.
    urgent: bool = False

    def apply(self, request: Request, context: Context) -> Dict[str, Any]:
        """Write the request; return what the ledger keeps for its withdrawal."""
        raise NotImplementedError

    def withdraw(self, entry: Entry, context: Context) -> None:
        """Undo what ``apply`` recorded, as far as the rows still exist."""
        raise NotImplementedError

    def confirm(self, request: Request, entry: Entry, context: Context) -> bool:
        """Whether an applied request still holds; False re-applies it."""
        return True

    def sweep(self, context: Context, entries: List[Entry]) -> int:
        """Once per process: remove what this kind wrote that no ledger
        entry names (a crash's leftovers). Returns how many were removed."""
        return 0
