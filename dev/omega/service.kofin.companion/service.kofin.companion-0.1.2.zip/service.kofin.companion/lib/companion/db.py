"""One connection per block to a gated Kodi database, carried from Kofin.

The exception path rolls back to the last commit; a block that changed a row
or left a transaction open commits on the way out, so the connection never
leaves a block idle inside a transaction with the write lock held.
"""

import sqlite3
from typing import Any, Dict, Optional

from companion import schema
from companion.log import Logger

LOG = Logger(__name__)

KINDS = ("video", "music", "texture")

_path_overrides: Dict[str, str] = {}


def set_path_override(kind: str, path: str) -> None:
    """Point a database kind at an explicit file (tests only)."""
    _path_overrides[kind] = path


def reset_overrides() -> None:
    _path_overrides.clear()


def locked(error: sqlite3.Error) -> bool:
    """Whether another connection held the file for longer than the wait."""
    text = str(error).lower()
    return "locked" in text or "busy" in text


def resolve_path(kind: str) -> str:
    if kind in _path_overrides:
        return _path_overrides[kind]
    if kind in KINDS:
        return schema.database_path(kind)
    return kind


class Database:
    """``with Database("video") as db: db.cursor.execute(...)``."""

    timeout: float = 120

    def __init__(
        self,
        kind: str = "video",
        commit_close: bool = True,
        timeout: Optional[float] = None,
    ) -> None:
        self.kind = kind
        self.commit_close = commit_close
        if timeout is not None:
            # How long a statement waits for a file another connection holds.
            self.timeout = timeout
        self.path = ""
        self.conn: Optional[sqlite3.Connection] = None
        self.cursor: sqlite3.Cursor

    def __enter__(self) -> "Database":
        self.path = resolve_path(self.kind)
        conn = sqlite3.connect(self.path, timeout=self.timeout)
        try:
            if self.kind in KINDS:
                conn.execute("PRAGMA journal_mode=WAL")
            self.cursor = conn.cursor()
        except BaseException:
            # __exit__ does not run for a block that never began, and the
            # pragma is the call that fails while Kodi holds the file: left
            # open, the connection keeps its lock until it is collected.
            conn.close()
            raise
        self.conn = conn
        LOG.debug("--->[ database: %s ] %s", self.kind, id(self.conn))
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        conn = self.conn
        assert conn is not None
        try:
            if exc_type is not None:
                # A handler's refusal leaves through here like any exception,
                # once per refused request per run: thousands of error lines
                # for answers that were never faults.
                say = LOG.debug if getattr(exc_type, "expected", False) else LOG.error
                say("type: %s value: %s", exc_type, exc_val)
                conn.rollback()
            elif self.commit_close and (conn.total_changes or conn.in_transaction):
                LOG.debug("[%s] %s rows updated.", self.kind, conn.total_changes)
                conn.commit()
        finally:
            LOG.debug("---<[ database: %s ] %s", self.kind, id(conn))
            self.cursor.close()
            conn.close()
            self.conn = None
