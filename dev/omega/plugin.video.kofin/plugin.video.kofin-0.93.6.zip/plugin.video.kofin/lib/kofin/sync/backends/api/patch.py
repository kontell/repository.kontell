"""The apply pass: desired state against the scanner's row, patched only
where they differ, confirmed by readback, acknowledged by the batch.

Setters merge maps and replace tags, so a patch clears only the keys Kofin
owned last time and keeps what Kodi or the user added. A refresh is the one
operation that replaces a row -- cast and streams have no setter -- and a show
refresh replaces every episode with it, so their local edits are captured
first and all of them rejoin the pass.

Music is confirmed by the scope, not the row. A song's patch is its play
count and last played; thousands of them on a first import would cost a
details call each to confirm, so the kinds the scanner derives are patched
in batches and then read back in one listing per library.
"""

import collections
import time
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import unquote

from kofin.core.log import Logger
from . import companion, metadata
from .kinds import (
    BATCH,
    DERIVED,
    EXPECTED,
    FILED,
    KINDS,
    ORDER,
    PLAYABLE,
    PROPERTIES,
    rpc,
    rpc_batch,
)
from .readback import artist_key
from .records import Record
from . import downloaded
from .store import Mapping, hash_matches, payload_hash

LOG = Logger(__name__)

# A refresh takes seconds; re-listing the scope every poll would re-read a
# library dozens of times for one changed item.
REFRESH_POLL = 1.0


def _with_asset_files(applied, assets, files, previous=None):
    """The acknowledged file list beside the token: the movie's current
    assets, or the empty entry once a movie that had assets has none, so
    the companion's desired set says they are gone (metadata.asset_files).
    ``previous`` is the last acknowledgement as it was read; whether the
    movie had assets is read from it, by its file list or, for an
    acknowledgement older than the list, by its assets token. Without the
    token a movie whose assets went while the earlier build ran had no
    entry at all, and the companion was never told its rows are gone."""
    if assets is None:
        return applied
    before = previous if previous is not None else applied
    had = "asset_files" in before or bool(before.get("assets"))
    if files is not None:
        if applied.get("asset_files") != files:
            applied = dict(applied, asset_files=files)
    elif had and applied.get("asset_files") != metadata.NO_ASSET_FILES:
        applied = dict(applied, asset_files=metadata.NO_ASSET_FILES)
    return applied


def _with_companion_fields(applied, record, kodi_id, previous=None):
    """What the companion's request kinds read from a mapping, so no payload
    is loaded to build them (companion.collect): an episode's favourite, a
    season's plot, a file's stream flags.

    A favourite is present only while it holds: the companion's withdrawal
    of that request unlinks the tag, so its absence is the whole message.
    A plot and stream flags are not like that. The companion leaves what
    it wrote when either request goes ("plot of season stands"), so a plot
    the server emptied, or flags it cleared, stayed on Kodi's row with
    nothing left asking for them to go. Once a row has carried either, the
    cleared value is kept and asked for (an empty plot, a zero for every
    stream) until the companion has acknowledged exactly that request; then
    the key goes. A row that never carried one is never asked for a clear.
    ``previous`` is the last acknowledgement when ``applied`` is a fresh
    one; what the row carried, and what the companion has acknowledged for
    it, is read from there.
    """
    item = record.item
    kind = record.kind
    before = previous if previous is not None else applied
    done = before.get("companion") or {}
    fields: Dict[str, Any] = {}
    if kind == "Episode" and (item.get("UserData") or {}).get("IsFavorite"):
        fields["favorite"] = True
    if kind == "Season":
        plot = (item.get("Overview") or "").strip(metadata.ASCII_SPACE)
        if plot:
            fields["plot"] = plot
        elif "plot" in before and not _cleared(
            done,
            companion.SEASON_PLOT,
            companion.season_plot_request(record.library, record.item_id, kodi_id, ""),
        ):
            fields["plot"] = ""
    if kind in ("Movie", "Episode", "MusicVideo"):
        flags = metadata.stream_flags(item)
        if flags is not None:
            fields["flags"] = flags
        elif "flags" in before:
            zero = metadata.cleared_stream_flags(item)
            if zero is not None and not _cleared(
                done,
                companion.STREAM_FLAGS,
                companion.stream_flags_request(
                    kind, record.library, record.item_id, kodi_id, zero
                ),
            ):
                fields["flags"] = zero
    changed = {k: v for k, v in fields.items() if applied.get(k) != v}
    gone = [
        k for k in ("favorite", "plot", "flags") if k in applied and k not in fields
    ]
    if not changed and not gone:
        return applied
    applied = dict(applied, **changed)
    for key in gone:
        del applied[key]
    return applied


def _cleared(done, kind, request) -> bool:
    """Whether the companion has acknowledged this very clearing request."""
    return bool(done.get(kind)) and done.get(kind) == companion.content_hash(request)


class Patch:
    def __init__(self, record, kodi_id, desired, compare, applied):
        self.record = record
        self.kodi_id = kodi_id
        self.desired = desired
        self.compare = compare
        self.applied = applied


class Applier:
    def __init__(self, native):
        self.native = native
        self.store = native.store
        self.key = native.key
        self.readback = native.readback
        # Per-pass write batches: thousands of one-row commits cost more than
        # the pass itself (measured: 3,685 database opens for a 1,788-movie
        # pass that sent no patch at all).
        self._acks: List[Tuple[str, int, Optional[int], Dict[str, Any], str]] = []
        self._expectations: List[Tuple[str, int, Dict[str, Any]]] = []
        self._mappings: Dict[str, Any] = {}
        self._mappings_loaded = False
        self.collections: Dict[str, str] = {}
        self.movies: Set[str] = set()
        self.local: Set[str] = set()
        # Music, per library: the album directories with a live song, the
        # artists a live album credits, and the Kodi album id each album's
        # songs were filed under -- read once a pass, not once a row.
        self._song_folders: Dict[str, Set[str]] = {}
        # Per show: the season numbers with an importable episode.
        self._seasons_with_episodes: Dict[str, Set[int]] = {}
        self._credited: Dict[str, Set[str]] = {}
        self._album_ids: Dict[str, Dict[str, Optional[int]]] = {}
        # Kodi's album and artist rows are not per library: two libraries
        # (or two albums of one) may share a row, and one of ours owns it.
        self._album_owners: Optional[Dict[int, str]] = None
        self._artist_owners: Optional[Dict[str, str]] = None
        self._deferred: List[Patch] = []
        self._rpc_seconds = 0.0
        self._failures: List[Tuple[str, int, str]] = []
        self._salted: Set[str] = set()
        # Downloaded items and the shows with a downloaded episode: their
        # rows carry the badge and the tag (downloaded.py), read once a pass.
        self.downloaded: Set[str] = set()
        self.downloaded_series: Dict[str, Set[str]] = {}
        self._downloaded_seasons: Dict[str, Set[int]] = {}
        # Whether a patch of this pass puts a download's badge on a row or
        # takes it off: Kodi announces neither (Native.announce_writes).
        self.badges_moved = False

    # -- batches -------------------------------------------------------------

    def ack(self, item_id, generation, kodi_id, applied, kind):
        self._acks.append((item_id, generation, kodi_id, applied, kind))
        if len(self._acks) >= 200:
            self.commit()

    def fail(self, record, error, errors):
        """Record a failure for the batch and keep the error for the pass."""
        self._failures.append(
            (
                record.item_id,
                record.generation,
                type(error).__name__ + ": " + str(error),
            )
        )
        errors.append(error)
        if len(self._failures) >= 200:
            self.commit()

    def commit(self):
        if self._failures:
            failures, self._failures = self._failures, []
            self.store.failed_many(failures)
        if self._expectations:
            self.store.expect_many(self._expectations)
            self._expectations = []
        if self._acks:
            acks, self._acks = self._acks, []
            self.store.remember_many(acks)
            if self._mappings_loaded:
                # Keep the preloaded mappings current without re-reading
                # them: a 24,000-row reload every 200 acknowledgements was
                # the pass's own largest cost.
                for item_id, _, kodi_id, applied, kind in acks:
                    self._mappings[item_id] = Mapping(kodi_id, applied or {}, kind)

    def mapping(self, item_id):
        if self._mappings_loaded:
            return self._mappings.get(item_id)
        return self.store.mapping(item_id)

    # -- the pass ------------------------------------------------------------

    def run(
        self,
        upserts: Dict[str, Record],
        collections,
        movies,
        repair,
        errors,
        kinds=ORDER,
    ):
        """Plan and patch the pass's records of ``kinds``, in that order."""
        self.downloaded, self.downloaded_series = downloaded.marks()
        self._downloaded_seasons = {}
        self.collections = collections
        self.movies = movies
        self.local = {item_id for item_id, _ in self.store.local_pending()}
        if not self._mappings_loaded:
            self._mappings = self.store.mappings()
            self._mappings_loaded = True
        queue: List[Patch] = []
        for kind in kinds:
            ids = sorted(i for i, r in upserts.items() if r.kind == kind)
            if not ids:
                continue
            began = time.monotonic()
            self._rpc_seconds = 0.0
            # The kind's name before its first row is counted: the readback
            # that comes first can take as long as the rows themselves.
            self.native.progress.note(self.native.progress.counted(kind))
            if kind == "BoxSet":
                # A library clear reads the set listing to see what it
                # emptied, and a movie patched since may have made a set that
                # listing never saw.
                self.readback.forget("BoxSet")
            if KINDS[kind].removal != "rescan":
                # A scope mostly about to be compared is read in full once.
                per_scope: Dict[Tuple[str, str], int] = {}
                for item_id in ids:
                    record = upserts[item_id]
                    scope = (record.library, record.parent_id)
                    if kind == "BoxSet":
                        scope = ("", "")
                    per_scope[scope] = per_scope.get(scope, 0) + 1
                for (library, parent_id), count in per_scope.items():
                    try:
                        self.readback.prefetch_full(kind, library, parent_id, count)
                    except InterruptedError:
                        raise
                    except Exception as error:
                        LOG.debug("full readback not prefetched: %s", error)
            for record in self.native.payloads.walk(upserts[i] for i in ids):
                try:
                    if self.native.abort():
                        raise InterruptedError("native sync stopped")
                    self.native.progress.step(kind)
                    patch = self.plan(record, repair)
                    if patch is not None:
                        queue.append(patch)
                        if len(queue) >= BATCH:
                            self.flush(queue, errors)
                except InterruptedError:
                    raise
                except Exception as error:
                    self.fail(record, error, errors)
            self.flush(queue, errors)
            if KINDS[kind].removal == "rescan":
                self.confirm_by_scope(kind, errors)
            self.commit()
            if kind == kinds[-1] or KINDS[kind].removal != "rescan":
                self.native.release_all()
            LOG.info(
                "%s: %d planned in %.1f s, %.1f s of it in Kodi calls",
                kind.lower(),
                len(ids),
                time.monotonic() - began,
                self._rpc_seconds,
            )

    # -- music lookups -------------------------------------------------------

    def song_folders(self, library) -> Set[str]:
        if library not in self._song_folders:
            self._song_folders[library] = set(self.store.folders("Audio", library))
        return self._song_folders[library]

    def albums(self, library) -> Dict[str, Dict[str, Any]]:
        """The library's album payloads, read once a pass and shared with
        the directory picker (MusicPass.album_items)."""
        items: Dict[str, Dict[str, Any]] = self.native.music.album_items(library)
        return items

    def credited(self, library) -> Set[str]:
        """The artist ids the library's live albums credit."""
        if library not in self._credited:
            artists: Set[str] = set()
            for item in self.albums(library).values():
                for credits in (item.get("AlbumArtists"), item.get("ArtistItems")):
                    for credit in credits or []:
                        if isinstance(credit, dict) and credit.get("Id"):
                            artists.add(str(credit["Id"]))
            self._credited[library] = artists
        return self._credited[library]

    def artist_owner(self, record: Record) -> str:
        """Kodi keeps one artist per name; of our artists sharing a name the
        first by id owns the row's art and description."""
        if self._artist_owners is None:
            owners: Dict[str, str] = {}
            for item_id, found in sorted(
                self.store.records(kind="MusicArtist").items()
            ):
                owners.setdefault(artist_key(found.item.get("Name")), item_id)
            self._artist_owners = owners
        return self._artist_owners.get(
            artist_key(record.item.get("Name")), record.item_id
        )

    def album_ids(self, library) -> Dict[str, Optional[int]]:
        if library not in self._album_ids:
            ids: Dict[str, Optional[int]] = {}
            for folder, rows in sorted(self.readback.folders(library).items()):
                counted = collections.Counter(
                    row.get("albumid") for row in rows.values() if row.get("albumid")
                )
                if counted:
                    ids[folder] = counted.most_common(1)[0][0]
            self._album_ids[library] = ids
        return self._album_ids[library]

    def album_id(self, record: Record) -> Optional[int]:
        """Kodi's id for the album the record's songs were filed under: the
        one most of them share."""
        return self.album_ids(record.library).get(record.item_id)

    def album_owner(self, albumid) -> Optional[str]:
        """Of our albums Kodi merged into one row, the first by id owns the
        row's art and description; the others are mapped and left."""
        if self._album_owners is None:
            owners: Dict[int, str] = {}
            for library in self.store.libraries("Audio"):
                for folder, found in sorted(self.album_ids(library).items()):
                    if found is not None and (
                        found not in owners or folder < owners[found]
                    ):
                        owners[found] = folder
            self._album_owners = owners
        return self._album_owners.get(albumid)

    def row_for(self, record: Record):
        kind = record.kind
        if kind == "Audio":
            return self.readback.scope("Audio", record.library, record.parent_id).get(
                record.item_id
            )
        if kind == "MusicAlbum":
            albumid = self.album_id(record)
            if albumid is None:
                return None
            return self.readback.scope("MusicAlbum", record.library).get(albumid)
        if kind == "MusicArtist":
            return self.readback.scope("MusicArtist", record.library).get(
                artist_key(record.item.get("Name"))
            )
        if kind == "Season":
            number = record.item.get("IndexNumber")
            if number is None:
                return None
            return self.readback.scope("Season", record.library, record.parent_id).get(
                int(number)
            )
        if kind == "BoxSet":
            name = (record.item.get("Name") or "").strip(metadata.ASCII_SPACE)
            return self.readback.scope("BoxSet").get(name)
        return self.readback.scope(kind, record.library, record.parent_id).get(
            record.item_id
        )

    def rowless(self, record: Record) -> bool:
        """Whether an item of this kind is applied with no native row.

        Kodi cannot file an unnumbered special; GetSeasons joins episodes,
        so an empty season is invisible; a set exists only once a movie Kodi
        holds has filed it under that very name -- a collection whose movies
        are outside the selected libraries, or the one a movie in two
        collections did not take, never has a row to find.
        """
        kind = record.kind
        if kind == "Episode":
            return metadata.episode_numbers(record.item) is None
        if kind == "Season":
            return not self.season_has_episodes(record)
        if kind == "MusicAlbum":
            # An album Kodi derives exists only through songs of ours in it.
            return record.item_id not in self.song_folders(record.library)
        if kind == "MusicArtist":
            # An artist no live album credits -- a guest on a track, or one
            # whose albums are outside the selection -- has no row of ours to
            # find by name; one whose albums have rows but whose name Kodi
            # spells otherwise has none either.
            if record.item_id not in self.credited(record.library):
                return True
            return self.row_for(record) is None
        if kind == "BoxSet":
            name = (record.item.get("Name") or "").strip(metadata.ASCII_SPACE)
            return not any(
                member in self.movies and self.collections.get(member) == name
                for member in record.item.get("KofinMembers") or []
            )
        return False

    def plan(self, record: Record, repair) -> Optional[Patch]:
        kind = record.kind
        if self.rowless(record):
            self.ack(record.item_id, record.generation, None, {}, kind)
            return None
        row = self.row_for(record)
        if row is None:
            if kind in ("Season", "BoxSet", "MusicAlbum"):
                # Its episodes, movies or songs are being imported this pass
                # or the next; nothing native to confirm yet.
                raise RuntimeError("%s has no native row yet" % kind)
            if kind == "Audio" and (
                (record.library, record.parent_id) in self.native.music.rescanned
                or (record.library, "*") in self.native.music.rescanned
            ):
                # Listed and scanned this pass and still absent: Kodi skipped
                # the directory "due to no change" -- a scan stopped before
                # its songs were written left their hash behind. Salt the
                # listing, once per directory and pass, so the next scan
                # sees a change (store.salt).
                if record.parent_id not in self._salted:
                    self._salted.add(record.parent_id)
                    self.store.bump_salt(record.parent_id)
                raise RuntimeError(
                    "scanner did not import Audio; directory salted (%d)"
                    % self.store.salt(record.parent_id)
                )
            raise RuntimeError("scanner did not import %s" % kind)
        if kind in DERIVED or kind == "Audio":
            return self.plan_music(record, row, repair)
        seasons = (
            [
                r.item
                for r in self.store.records(
                    kind="Season", parent_id=record.item_id
                ).values()
            ]
            if kind == "Series"
            else ()
        )
        set_name = self.collections.get(record.item_id, "") if kind == "Movie" else None
        mark = downloaded.flag(
            kind,
            record.item_id,
            self.downloaded,
            self.downloaded_series,
            season=kind == "Season" and self.season_is_downloaded(record),
        )
        mapping = self.mapping(record.item_id)
        previous = mapping.applied if mapping else {}
        if record.item_id in self.local:
            # Deliver the real user edit first. Never overwrite it with an
            # older server snapshot during a retry or a refresh.
            return None
        if kind in PLAYABLE and previous.get("userdata"):
            # The scope row carries the userdata, so a viewer's edit is seen
            # before anything else is read or built.
            edits = local_edits(
                row, previous["userdata"], metadata.userdata(record.item)
            )
            if edits:
                self.store.local(record.item_id, edits)
                return None
        kodi_id = row[KINDS[kind].id_param]
        payload = payload_hash(record.item)
        inputs = metadata.inputs_token(
            self.native.server_url(),
            self.key,
            record.library,
            self.native.separator,
            seasons,
            set_name,
            downloaded=mark,
        )
        # The versions and extras the movie's folder listed, acknowledged so
        # the pass stops scanning the folder for them (native._asset_folders).
        assets = metadata.assets_token(record.item) if kind == "Movie" else None
        files = (
            metadata.asset_files(record.item, self.key, record.library)
            if kind == "Movie"
            else None
        )
        if (
            not repair
            # A set's id is no proof of its row: Kodi numbers a new set from
            # the highest one left, so a set deleted and made again answers
            # under the number it was acknowledged by (Native.join_sets).
            and kind != "BoxSet"
            and mapping is not None
            and mapping.kodi_id == kodi_id
            and hash_matches(previous.get("hash"), record.item)
            and previous.get("inputs") == inputs
        ):
            # The desired state this payload and these inputs produce was
            # acknowledged against this very row: nothing to build, read or
            # compare. A retried pass and a re-published item take this path.
            acked = previous
            if assets is not None and previous.get("assets", "") != assets:
                acked = dict(previous, assets=assets)
            acked = _with_asset_files(acked, assets, files, previous)
            acked = _with_companion_fields(acked, record, kodi_id)
            self.ack(record.item_id, record.generation, kodi_id, acked, kind)
            return None
        desired = metadata.details(
            record.item,
            self.native.server_url(),
            self.key,
            record.library,
            self.native.separator,
            seasons,
            set_name,
        )
        downloaded.apply(kind, desired, mark)
        parts = metadata.refresh_parts(record.item, seasons) if kind in FILED else {}
        if kind in FILED:
            token = desired["uniqueid"]["kofinrefresh"]
            if (row.get("uniqueid") or {}).get("kofinrefresh") != token:
                LOG.info(
                    "refreshing %s %s: %s",
                    kind.lower(),
                    record.item_id,
                    moved_parts(previous.get("refresh"), parts),
                )
                row = self.refresh(record, kodi_id, token)
                kodi_id = row[KINDS[kind].id_param]
        # Only now the full row: the scope carries what finds and owns it.
        row = self.readback.full(kind, record.library, record.parent_id, row)
        applied = {
            "hash": payload,
            "inputs": inputs,
            "owned": metadata.owned(desired),
        }
        if parts:
            applied["refresh"] = parts
        if assets is not None:
            applied["assets"] = assets
        applied = _with_asset_files(applied, assets, files, previous)
        if previous.get("companion"):
            # What the companion has done for this row, kept across plans
            # (companion.collect compares it with the request it would make).
            applied["companion"] = previous["companion"]
        applied = _with_companion_fields(applied, record, kodi_id, previous)
        compare = merge(kind, desired, row, previous.get("owned", {}))
        if kind in PLAYABLE:
            applied["userdata"] = metadata.userdata(record.item)
        if kind in EXPECTED:
            self._expectations.append(
                (record.item_id, record.generation, applied["userdata"])
            )
        # A withdrawn season name is a clear the readback cannot show.
        clearing = kind == "Season" and desired.get("title") == ""
        if (
            not clearing
            and matches(row, compare)
            # Repair re-sends a row whose acknowledged hash moved, for the
            # fields a readback cannot show. A row with no acknowledgement
            # yet was just filed by the scanner from this very listing:
            # there is nothing stale behind it, and the pass that follows
            # every complete enumeration runs as a repair, so without this
            # a first import re-wrote all 6,200 of its rows (a tablet spent
            # an hour on it).
            and (
                not repair
                or mapping is None
                or hash_matches(previous.get("hash"), record.item)
            )
        ):
            self.ack(record.item_id, record.generation, kodi_id, applied, kind)
            return None
        if (downloaded.BADGE_ART in (row.get("art") or {})) != bool(mark):
            self.badges_moved = True
        return Patch(record, kodi_id, desired, compare, applied)

    def plan_music(self, record: Record, row, repair) -> Optional[Patch]:
        kind = record.kind
        table = KINDS[kind]
        kodi_id = row[table.id_param]
        mapping = self.mapping(record.item_id)
        previous = mapping.applied if mapping else {}
        desired = metadata.details(record.item, self.native.server_url(), self.key, "")
        applied: Dict[str, Any] = {
            "hash": payload_hash(record.item),
            "owned": metadata.owned(desired),
        }
        if kind == "Audio":
            if record.item_id in self.local:
                return None
            if previous.get("userdata"):
                edits = local_edits(row, previous["userdata"], desired)
                if edits:
                    self.store.local(record.item_id, edits)
                    return None
            applied["tag"] = self.native.music.tag_hash(record)
            applied["dir"] = record.parent_id
            applied["userdata"] = metadata.userdata(record.item)
            if previous.get("tag") not in (None, applied["tag"]) and not (
                (record.library, record.parent_id) in self.native.music.rescanned
                or (record.library, "*") in self.native.music.rescanned
            ):
                # The tags moved and the directory was not re-listed this
                # pass: the row still carries the old ones.
                raise RuntimeError("song awaits its directory's rescan")
        elif kind == "MusicAlbum":
            owner = self.album_owner(kodi_id)
            if owner is not None and owner != record.item_id:
                # Kodi merged two of our albums into one row; the first owns
                # its art and description, the other is mapped and left.
                self.ack(record.item_id, record.generation, kodi_id, {}, kind)
                return None
        elif kind == "MusicArtist":
            if self.artist_owner(record) != record.item_id:
                self.ack(record.item_id, record.generation, kodi_id, {}, kind)
                return None
        compare = merge(kind, desired, row, previous.get("owned", {}))
        if matches(row, compare) and (
            # A song's desired state is its play count and last played, and
            # the readback shows both: a matching row has nothing a repair
            # could re-send, and the setter is not free -- UpdateSong
            # rewrites the song's dateAdded from the file's timestamp, which
            # for a plugin path is the moment of the call.
            kind == "Audio"
            # As for video (plan): a row with no acknowledgement was filed
            # by the scanner from this very listing, and the pass after a
            # complete enumeration runs as a repair. Without this a first
            # import sent a setter for every song, 230 ms each on a
            # Raspberry Pi: 308 s of a 357 s pass for 1,353 songs, six of
            # them ever played.
            or not repair
            or mapping is None
            or hash_matches(previous.get("hash"), record.item)
        ):
            self.ack(record.item_id, record.generation, kodi_id, applied, kind)
            return None
        return Patch(record, kodi_id, desired, compare, applied)

    def season_is_downloaded(self, season: Record) -> bool:
        number = season.item.get("IndexNumber")
        if number is None or season.parent_id not in self.downloaded_series:
            return False
        return int(number) in self.downloaded_seasons(season.parent_id)

    def downloaded_seasons(self, series_id: str) -> Set[int]:
        """The season numbers of a show that hold a downloaded episode, read
        once a show: the payloads of its downloaded episodes, which are few,
        and only for a show that has any."""
        if series_id not in self._downloaded_seasons:
            found: Set[int] = set()
            episodes = sorted(self.downloaded_series.get(series_id) or ())
            for item in self.store.payloads(episodes).values():
                numbers = metadata.episode_numbers(item)
                if numbers is not None:
                    found.add(numbers["season"])
            self._downloaded_seasons[series_id] = found
        return self._downloaded_seasons[series_id]

    def season_has_episodes(self, season: Record) -> bool:
        number = season.item.get("IndexNumber")
        if number is None:
            return False
        return int(number) in self.seasons_with_episodes(season.parent_id)

    def seasons_with_episodes(self, series_id: str) -> Set[int]:
        """The season numbers of a show that hold an importable episode,
        read once a show. Asked per season, every season of a show read
        every episode payload of the show again: 347 seasons were 349 s of
        a pass on a Raspberry Pi, the show's episodes parsed once for each
        of its seasons."""
        if series_id not in self._seasons_with_episodes:
            found: Set[int] = set()
            for episode in self.store.records(
                kind="Episode", parent_id=series_id
            ).values():
                numbers = metadata.episode_numbers(episode.item)
                if numbers is not None:
                    found.add(numbers["season"])
            self._seasons_with_episodes[series_id] = found
        return self._seasons_with_episodes[series_id]

    # -- refresh -------------------------------------------------------------

    def refresh(self, record: Record, kodi_id, token):
        """Re-import a row whose cast or streams changed; confirmed by token.

        A show is refreshed alone. Kodi then rewrites the show's own row
        from the listing, cast included, and keeps its id, its seasons and
        its episodes (CVideoInfoScanner::RetrieveInfoForTvShow, the
        refresh-show-info-only branch: one OnUpdate, 0.3 s on a desktop).
        Asked to refresh the episodes too, it deletes the show and every
        episode and imports them again under new ids, so a recast show lost
        its play counts to whatever the catalogue held and was announced
        row by row to every widget. What a show refresh cannot do is change
        the plot of a season Kodi already has (AddSeason only inserts); that
        is the companion's (companion.season_plot_request).
        """
        kind = record.kind
        table = KINDS[kind]
        if table.refresh is None:
            raise RuntimeError("%s has no refresh" % kind)
        self.readback.owned(
            kind, kodi_id, record.item_id, record.library, record.parent_id
        )
        params: Dict[str, Any] = {table.id_param: kodi_id, "ignorenfo": False}
        if kind == "Series":
            params["refreshepisodes"] = False
        rpc(table.refresh, params)
        self.native._async_pending = True
        last = [0.0]

        def refreshed():
            now = time.monotonic()
            if now - last[0] < REFRESH_POLL:
                return None
            last[0] = now
            self.readback.forget(kind, record.library, record.parent_id)
            found = self.readback.scope(kind, record.library, record.parent_id).get(
                record.item_id
            )
            if found and (found.get("uniqueid") or {}).get("kofinrefresh") == token:
                return found
            return None

        row = self.native.wait(refreshed, busy=self.native._scanning)
        self.native._async_pending = False
        return row

    # -- patches -------------------------------------------------------------

    def confirm_by_scope(self, kind, errors):
        """Read the kind's rows back in one listing per library and settle
        every deferred patch against it."""
        if not self._deferred:
            return
        patches, self._deferred = self._deferred, []
        for library in sorted({p.record.library for p in patches}):
            self.readback.forget(kind, library)
        for patch in patches:
            record = patch.record
            try:
                row = self.row_for(record)
                if row is None:
                    raise RuntimeError("%s row vanished after its patch" % kind)
                if not matches(row, patch.compare):
                    fields = [
                        key
                        for key, value in patch.compare.items()
                        if not matches(row, {key: value})
                    ]
                    raise RuntimeError(
                        "%s detail readback differs: %s" % (kind, ", ".join(fields))
                    )
                self.ack(
                    record.item_id,
                    record.generation,
                    patch.kodi_id,
                    patch.applied,
                    kind,
                )
            except InterruptedError:
                raise
            except Exception as error:
                self.fail(record, error, errors)

    def flush(self, queue: List[Patch], errors):
        if not queue:
            return
        patches, queue[:] = list(queue), []
        # Expectations go in ahead of the setters they cover.
        if self._expectations:
            self.store.expect_many(self._expectations)
            self._expectations = []
        # Kodi logs no announcements, so this line is the only count of
        # what a pass actually wrote (an import whose rows match sends none).
        LOG.info("patching %d %s rows", len(patches), patches[0].record.kind.lower())
        if KINDS[patches[0].record.kind].removal == "rescan":
            # Writes announced during a music scan are a transaction to the
            # home widgets: hold the scanner for the burst (native.hold).
            self.native.hold("music")
        setters: List[Tuple[str, Optional[Dict[str, Any]]]] = []
        for patch in patches:
            table = KINDS[patch.record.kind]
            params = dict(patch.desired)
            params[table.id_param] = patch.kodi_id
            setters.append((table.setter, params))
        began = time.monotonic()
        replies = rpc_batch(setters)
        self._rpc_seconds += time.monotonic() - began
        # Every setter announced its row (native.pump).
        self.native.pump()
        confirmations: List[Tuple[str, Optional[Dict[str, Any]]]] = []
        confirming = []
        for patch, reply in zip(patches, replies):
            if isinstance(reply, Exception):
                self.fail(patch.record, reply, errors)
                continue
            table = KINDS[patch.record.kind]
            if table.removal == "rescan":
                # Confirmed by the scope once the kind's patches are all sent.
                self._deferred.append(patch)
                continue
            confirmations.append(
                (
                    table.getter,
                    {
                        table.id_param: patch.kodi_id,
                        "properties": PROPERTIES[patch.record.kind],
                    },
                )
            )
            confirming.append(patch)
        for patch, reply in zip(confirming, rpc_batch(confirmations)):
            record = patch.record
            try:
                if isinstance(reply, Exception):
                    raise reply
                row = (
                    reply.get(KINDS[record.kind].result_key, {})
                    if isinstance(reply, dict)
                    else {}
                )
                if record.kind in FILED:
                    if (
                        self.readback.owns(
                            record.kind, row, record.library, record.parent_id
                        )
                        != record.item_id
                    ):
                        raise RuntimeError("%s ownership changed" % record.kind)
                if not matches(row, patch.compare):
                    fields = [
                        key
                        for key, value in patch.compare.items()
                        if not matches(row, {key: value})
                    ]
                    raise RuntimeError(
                        "%s detail readback differs: %s"
                        % (record.kind, ", ".join(fields))
                    )
                self.ack(
                    record.item_id,
                    record.generation,
                    patch.kodi_id,
                    patch.applied,
                    record.kind,
                )
                cache_key: Any = record.item_id
                if record.kind == "Season":
                    cache_key = int(record.item.get("IndexNumber") or 0)
                elif record.kind == "BoxSet":
                    cache_key = row.get("title", "")
                self.readback.remember(
                    record.kind, record.library, record.parent_id, cache_key, row
                )
            except InterruptedError:
                raise
            except Exception as error:
                self.fail(record, error, errors)


def moved_parts(before, now) -> str:
    """Which parts of a refresh token moved, for the log. A row acknowledged
    by an earlier build has no parts on record, and one the scanner filed
    and nothing acknowledged has none either."""
    if not before:
        return "what moved is not on record"
    moved = sorted(
        part for part in set(before) | set(now) if before.get(part) != now.get(part)
    )
    return "its %s moved" % ", ".join(moved) if moved else "nothing on record moved"


def local_edits(row, previous, desired):
    """Userdata the viewer changed in Kodi since the last write, if any.

    A viewer's edit of a play count is the watched mark going on or off. A
    count that differs only in size is Kodi and the server having counted
    differently, and the server's count is then written to Kodi like any
    other field: read as an edit, it sent Kodi's count up to the server
    after every play."""
    edits = {}
    playcount = row.get("playcount", 0) or 0
    watched = bool(playcount)
    if watched != bool(previous.get("playcount")) and watched != bool(
        desired["playcount"]
    ):
        edits["playcount"] = playcount
    if "resume" not in desired:
        # A song: Kodi's music library keeps no resume point.
        return edits
    position = (row.get("resume") or {}).get("position", 0) or 0
    if (
        abs(position - previous.get("resume", {}).get("position", 0)) >= 1
        and abs(position - desired["resume"]["position"]) >= 1
    ):
        edits["position"] = position
    return edits


def merge(kind, desired, row, owned_before):
    """Setters merge maps and replace tags. Clear only keys previously owned
    by Kofin, retaining Kodi defaults and local additions. Returns the state
    the readback must match; ``desired`` is updated in place to send."""
    compare = dict(desired)
    if "tag" in compare:
        old_tags = set(owned_before.get("tag", [])) | {
            tag for tag in row.get("tag", []) if tag.startswith("kofin.library.")
        }
        compare["tag"] = sorted(
            set(compare["tag"]) | (set(row.get("tag", [])) - old_tags)
        )
        desired["tag"] = compare["tag"]
    for field in ("art", "ratings", "uniqueid"):
        if field not in compare:
            continue
        owned = set(owned_before.get(field, []))
        if field == "art":
            # tvshow.* and season.* art is Kodi's own, read off the show and
            # season rows; an acknowledgement that listed such a key (before
            # metadata.details stopped carrying them) must not try to clear
            # it, which no episode setter can do.
            owned = {key for key in owned if "." not in key}
        merged = dict(compare[field])
        merged.update({key: None for key in owned if key not in merged})
        merged.update(
            {
                key: value
                for key, value in (row.get(field) or {}).items()
                if key not in merged and key not in owned and key != "icon"
            }
        )
        if field == "art":
            merged = {
                key: (
                    unquote(value[8:].rstrip("/"))
                    if isinstance(value, str) and value.startswith("image://")
                    else value
                )
                for key, value in merged.items()
                # Inherited keys are neither sent nor compared: Kodi reads
                # them off the show and season rows, and setting one on an
                # episode only pins a copy that goes stale when the show's
                # art moves.
                if "." not in key
            }
        desired[field] = merged
        compare[field] = merged
    if kind == "Season":
        if not desired.get("title"):
            if "title" in owned_before:
                desired["title"] = ""
            else:
                desired.pop("title", None)
            compare.pop("title", None)
        compare.pop("uniqueid", None)
        desired.pop("uniqueid", None)
    return compare


def matches(row, desired):
    for key, value in desired.items():
        actual = row.get(key)
        if key == "resume":
            if abs((actual or {}).get("position", 0) - value["position"]) >= 1:
                return False
        elif key in ("ratings", "uniqueid", "art"):
            actual = actual or {}
            for name, wanted in value.items():
                got = actual.get(name)
                if key == "art" and isinstance(got, str) and got.startswith("image://"):
                    got = unquote(got[8:].rstrip("/"))
                if key == "ratings" and wanted:
                    if (
                        not got
                        or abs(got["rating"] - wanted["rating"]) >= 0.01
                        or got.get("votes", 0) != wanted["votes"]
                    ):
                        return False
                elif (got or None) != (wanted or None):
                    return False
        elif key == "rating":
            if abs(float(actual or 0) - float(value or 0)) >= 0.01:
                return False
        elif key == "lastplayed":
            if not metadata.same_play(actual or "", value or ""):
                return False
        elif isinstance(value, list):
            if sorted(actual or []) != sorted(value):
                return False
        elif isinstance(value, (int, float)) and not isinstance(value, bool):
            if (actual or 0) != value:
                return False
        elif (actual or "") != (value or ""):
            return False
    return True
